(function(root){
'use strict';
const M=typeof module!=='undefined'&&module.exports?require('./money.js'):root.LifeMoney;
const D=typeof module!=='undefined'&&module.exports?require('./data.js'):root.LifeData;
const clamp=(n,a=0,b=100)=>Math.max(a,Math.min(b,n));
const rounded=n=>M.max(0,M.round(n));
const NEW_SKILLS=['politica','oratoria','lideranca','diplomacia','financas','medicina','atuacao','fotografia'];
function hash(text){let h=2166136261;for(const c of String(text)){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}
const careers={comum:'Profissional da comunidade',cinema:'Ator de cinema',musica:'Artista musical',esporte:'Atleta',internet:'Criador de conteúdo',ciencia:'Pesquisador',negocios:'Empreendedor'};
function socialDefaults(p){const n=hash(p.id+'/'+p.name);return {popularity:p.age<16?3+n%12:5+n%26,career:Object.keys(careers)[n%7],talent:25+n%76};}
function careerTitle(p){if(p.age<16)return 'Estudante';if(p.career==='cinema'&&p.popularity>=85)return 'Astro de Hollywood';return careers[p.career]+(p.popularity>=70?' · celebridade':p.popularity>=45?' · em ascensão':'');}
function influence(s){const items=s.people.filter(p=>p.alive&&p.kind==='friend').map(p=>({id:p.id,name:p.name,popularity:p.popularity,bond:p.bond,weight:(1.5+p.popularity*.15+90*Math.pow(p.popularity/100,4))*p.bond/100}));const raw=items.reduce((n,p)=>n+p.weight,0),network=100*(1-Math.exp(-raw/55)),popularity=clamp(s.fame+(100-s.fame)*network/100);return {personal:s.fame,network,popularity,items:items.sort((a,b)=>b.weight-a.weight)};}
function evolveFriend(s,p,random,log){
 if(p.kind!=='friend'||!p.alive||p.age<16)return;
 const before=p.popularity,oldTitle=careerTitle(p);
 if(p.career==='comum'&&random(s)<.08){p.career=['cinema','musica','esporte','internet','ciencia','negocios'][hash(p.id+'/'+s.year)%6];log(s,p.name+' começou um novo caminho: '+careers[p.career]+'.','✨','pessoas');}
 const r=random(s);let growth=r<.12?-Math.ceil(2+random(s)*5):r<.70?Math.ceil(1+p.talent/35):0;
 if(p.career!=='comum'&&random(s)<.06+p.talent/2500)growth+=12+Math.floor(random(s)*14);
 p.popularity=clamp(before+growth,0,p.career==='comum'?40:100);
 const newTitle=careerTitle(p);
 if(newTitle!==oldTitle&&p.popularity>=45)log(s,p.name+' agora é '+newTitle.charAt(0).toLowerCase()+newTitle.slice(1)+'. Essa amizade amplia sua popularidade.','🌟','pessoas');
 else if(p.popularity-before>=12)log(s,'A carreira de '+p.name+' ganhou destaque. Popularidade: '+Math.round(p.popularity)+'/100.','🌟','pessoas');
}
const circles={bairro:{name:'Pessoas do bairro',cost:80,hours:6,min:6,pop:0,low:5,high:30},cinema:{name:'Oficina de cinema',cost:1200,hours:24,min:16,pop:0,low:15,high:50,career:'cinema'},profissional:{name:'Encontro profissional',cost:500,hours:12,min:16,pop:0,low:25,high:60},celebridades:{name:'Gala de artistas',cost:5000,hours:48,min:18,pop:35,low:60,high:95}};
function maintenance(s,d,supported=false){const rate=d.type==='vehicle'?Math.min(.8,s.skills.mecanica*.006+['motores','suspensao','eletronica','restauracao'].reduce((n,k)=>n+(s.skills[k]||0),0)*.0005):0;return {base:d.upkeep,rate,cost:rounded(d.upkeep*(1-rate)*(supported&&d.type==='vehicle'?.5:1))};}
function trainingFactor(s,id){const d=D.skills[id],stat=D.stats[d.stat]?d.stat:'smarts';return .7+s.stats[stat]/200+s.stats.health/500;}
function projectFactor(s,id){const d=D.skills[id],stat=D.stats[d.stat]?d.stat:'smarts';return .7+s.stats[stat]/200;}
function battle(s,strategy='tecnico'){
 const t=s.tournament;if(!t)return null;const d=D.tournaments.find(x=>x.id===t.id),op=t.opponents[t.round];
 const counters={agressivo:'tecnico',tecnico:'defensivo',defensivo:'agressivo'},counter=counters[op.style]===strategy?8:counters[strategy]===op.style?-6:0,style=strategy==='agressivo'?4:strategy==='tecnico'?2:0;
 const power=s.skills[d.skill]*.65+s.stats[d.stat]*.30+s.stats.health*.05+t.stamina*.08+counter+style;
 const guaranteed=t.id==='xadrez'&&s.stats.smarts>=80&&s.skills.xadrez>op.power;
 return {power,chance:guaranteed?1:clamp(.5+(power-(op.power+15))/85,.03,.97),guaranteed,attribute:d.stat,opponentSkill:op.power,reason:guaranteed?'Vitória garantida: intelecto 80+ e xadrez acima da habilidade adversária.':'Habilidade, atributo, saúde, fôlego e estratégia compõem sua chance.'};
}
const offices=[{id:'prefeito',name:'Prefeito',icon:'🏘️',min:18,req:20,cost:3000,pay:60000,difficulty:0},{id:'governador',name:'Governador',icon:'🏛️',min:25,req:40,cost:25000,pay:120000,difficulty:8},{id:'presidente',name:'Presidente',icon:'🌐',min:35,req:60,cost:150000,pay:240000,difficulty:15}];
const policies={educacao:{name:'Educação',icon:'📚',desc:'Expandir escolas e formação.'},saude:{name:'Saúde',icon:'🩺',desc:'Melhorar o atendimento da população.'},infraestrutura:{name:'Infraestrutura',icon:'🏗️',desc:'Cuidar de transporte e serviços.'},transparencia:{name:'Transparência',icon:'🔎',desc:'Fiscalizar contas e abrir dados públicos.'}};
function emptyPolitics(){return {office:null,campaign:null,elections:[],experience:0,lastElectionYear:-1,policyYear:-1};}
function campaignQuote(s,id,budget='base'){const d=offices.find(x=>x.id===id);return d?{...d,budget,cost:d.cost*(budget==='ampla'?3:1),hours:120}:null;}
function electionForecast(s,id){
 const d=offices.find(x=>x.id===(id||(s.politics.campaign||{}).id));if(!d)return null;const c=s.politics.campaign,network=influence(s),withoutFriends=s.fame,celebrityReach=network.items.reduce((n,p)=>n+Math.pow(p.popularity/100,4)*p.bond/100,0),celebrityBonus=12*(1-Math.exp(-celebrityReach/1.5)),i=s.governments[d.id]&&s.governments[d.id].civic?s.governments[d.id].civic.institutions:null,institutionBonus=i&&i.parties==='unico'?6:i&&i.parties==='coalizao'?2:0;
 const factors=[{label:'Reputação',value:s.reputation*.23},{label:'Popularidade (inclui amigos)',value:network.popularity*.22},{label:'Política',value:s.skills.politica*.20},{label:'Oratória',value:s.skills.oratoria*.13},{label:'Carisma',value:s.stats.charisma*.10},{label:'Intelecto',value:s.stats.smarts*.05},{label:'Liderança',value:s.skills.lideranca*.07}];
 const effort=c&&c.id===d.id?c.effort*1.5+(c.budget==='ampla'?3:0):0,experience=Math.min(5,s.politics.experience*.25),penalty=Math.min(15,s.record*3),score=factors.reduce((n,x)=>n+x.value,0);
 const votes=clamp(20+score*.60-d.difficulty+effort+experience+celebrityBonus+institutionBonus-penalty,2,98);
 return {id:d.id,votes,low:clamp(votes-6,2,98),high:clamp(votes+6,2,98),factors,effort,experience,penalty,celebrityBonus,institutionBonus,friendsVotes:Math.max(0,votes-clamp(20+(score-(network.popularity-withoutFriends)*.22)*.60-d.difficulty+effort+experience+institutionBonus-penalty,2,98)),popularity:network.popularity};
}
function policyStrength(s){return (s.skills.politica*.4+s.skills.lideranca*.25+s.skills.diplomacia*.15+s.stats.smarts*.2)/100;}
// Mercado inteiramente fictício. O caminho depende da idade e da semente da vida,
// nunca do relógio, de cotações reais ou da ordem de compra e venda.
const coins=[{id:'ambar',name:'Âmbar',ticker:'AMB',icon:'🟠'},{id:'orbita',name:'Órbita',ticker:'ORB',icon:'🪐'},{id:'marea',name:'Maréa',ticker:'MAR',icon:'🌊'},{id:'prisma',name:'Prisma',ticker:'PRI',icon:'🔷'},{id:'pulso',name:'Pulso',ticker:'PUL',icon:'💜'},{id:'faisca',name:'Faísca',ticker:'FAI',icon:'⚡'},{id:'vertice',name:'Vértice',ticker:'VER',icon:'🔺'},{id:'raiz',name:'Raiz',ticker:'RAI',icon:'🌱'}];
const fundamentals=[
 'Oferta máxima imutável de 24 milhões de unidades, emissão previsível e decrescente, rede aberta sem controlador central, validação independente e regras públicas que qualquer pessoa pode verificar.',
 'A fundação pode aumentar a oferta. Uma equipe pequena aprova as transações e pode suspender saques para manter a rede.',
 'Preço sustentado por recompensas muito altas para novos participantes. A emissão é ilimitada e depende da entrada de compradores.',
 'Token usado em um único aplicativo de entretenimento. A empresa responsável controla as reservas e pode mudar as regras.',
 'Divulgação por influenciadores e promessas de grandes parcerias. A maior parte das unidades está concentrada nos criadores.',
 'Rede rápida operada por três servidores da mesma empresa. A oferta e as taxas são alteradas por decisão interna.',
 'Ativo anunciado como estável, mas sem reservas verificáveis. O mecanismo depende da compra contínua de outro token do grupo.',
 'Moeda de uma tendência passageira. Não tem limite de emissão, validação independente nem plano de manutenção da rede.'
];
function emptyMarket(seed){return {seed:(hash(seed+'/mercado')||1),holdings:Object.fromEntries(coins.map(c=>[c.id,0])),trades:[],collapsed:{},adjustment:{recovered:0,liquidated:0,year:0}};}
function profile(s,id){const i=coins.findIndex(c=>c.id===id);if(i<0)return -1;return (i+8-s.market.seed%8)%8;}
function coinInfo(s,id){const c=coins.find(x=>x.id===id);return c?{...c,description:fundamentals[profile(s,id)],supply:supply(s,id),share:Number(s.market.holdings[id])/supply(s,id)*100}:null;}
const ATOMS=100000000n;
function unitAtoms(value){const [n,d]=M.parts(value);if(n<0n)throw Error('Quantidade inválida.');return M.div(n*ATOMS,d);}
function unitOut(n){const whole=n/ATOMS,rest=(n%ATOMS).toString().padStart(8,'0').replace(/0+$/,''),text=whole.toString()+(rest?'.'+rest:''),number=Number(text);return unitAtoms(number)===n?number:text;}
function supply(s,id,age=s.age){const p=profile(s,id),base=[24000000,120000000,500000000,80000000,1000000000,600000000,2000000000,10000000000][p];return base===undefined?0:Math.round(base*([2,7].includes(p)?1+Math.max(0,age)*.025:1));}
function oldPrice(s,id,age=s.age){const i=coins.findIndex(c=>c.id===id);if(i<0)return 0;if(age>=30)return profile(s,id)===0?1000000:0;const waves=[1,3.8,.45,8,.8,14,.25,24,1.5,40],shift=hash(s.market.seed+'/'+id)%10,base=4+hash(id+'/'+s.market.seed)%17;return Math.round(base*waves[(Math.max(0,Math.floor(age))+shift)%10]*(1+Math.max(0,age)*.08)*100)/100;}
function price(s,id,age=s.age){if(!coins.some(c=>c.id===id))return 0;const collapse=s.market.collapsed&&s.market.collapsed[id];if(collapse&&(age===s.age||age>=collapse.age))return 0;return age>=30?(profile(s,id)===0?1000000000:0):oldPrice(s,id,age);}
function unitsValue(units,quote,mode='floor'){const cents=BigInt(Math.round(quote*100));return M.out(M.div(unitAtoms(units)*cents,ATOMS*100n,mode));}
function cryptoWorth(s,age=s.age){return M.add(...coins.map(c=>unitsValue(s.market.holdings[c.id],price(s,c.id,age))));}
function tradeQuote(s,id,operation,amount,mode='reais'){
 const unitPrice=price(s,id);if(!coins.some(c=>c.id===id)||!['buy','sell','sellAll'].includes(operation)||!['reais','unidades'].includes(mode))return null;
 let atoms,total;try{
  if(operation==='sellAll'){atoms=unitAtoms(s.market.holdings[id]);total=unitsValue(unitOut(atoms),unitPrice);}
  else if(mode==='unidades'){const [n,d]=M.parts(amount);if(n<=0n||n*ATOMS%d!==0n)return null;atoms=n*ATOMS/d;total=unitsValue(unitOut(atoms),unitPrice,operation==='buy'?'ceil':'floor');}
  else{const budget=M.input(amount);if(budget===null||M.cmp(budget,1)<0)return null;if(unitPrice===0)return null;const cents=BigInt(Math.round(unitPrice*100));atoms=M.div(M.integer(budget)*100n*ATOMS,cents,operation==='buy'?'floor':'ceil');total=unitsValue(unitOut(atoms),unitPrice,operation==='buy'?'ceil':'floor');}
  const held=unitAtoms(s.market.holdings[id]),after=operation==='buy'?held+atoms:held-atoms,offer=supply(s,id),willCollapse=operation==='buy'&&after>BigInt(offer)*ATOMS/2n;
  return {id,operation,mode,price:unitPrice,units:unitOut(atoms),total,hours:1,supply:offer,share:Number(after)/Number(BigInt(offer)*ATOMS)*100,after:after>=0n?unitOut(after):0,willCollapse,overSupply:after>BigInt(offer)*ATOMS};
 }catch(e){return null;}
}
function migrateMarket(s){
 const m=s.market;if(!m||!Number.isInteger(m.seed)||m.seed<1||!m.holdings||coins.some(c=>typeof m.holdings[c.id]!=='number'||!Number.isFinite(m.holdings[c.id])||m.holdings[c.id]<0||m.holdings[c.id]>1e12)||!Array.isArray(m.trades)||m.trades.length>40)throw Error('Mercado antigo inválido.');
 m.collapsed={};let recovered=0,liquidated=0;
 for(const t of m.trades){if(!t||!coins.some(c=>c.id===t.id)||!['buy','sell','sellAll'].includes(t.operation)||!Number.isFinite(t.units)||t.units<0||t.units>1e12||!Number.isFinite(t.price)||t.price<0||t.price>1e6||!Number.isFinite(t.total)||t.total<0||t.total>1e12)throw Error('Histórico antigo inválido.');if(t.operation!=='buy'){const gross=unitsValue(t.units,t.price,'round');if(t.total===1e12&&M.cmp(gross,t.total)>0)recovered=M.add(recovered,M.sub(gross,t.total));}t.units=unitOut(unitAtoms(t.units));}
 for(const c of coins){const atoms=unitAtoms(m.holdings[c.id]);if(atoms>BigInt(supply(s,c.id))*ATOMS/2n){liquidated=M.add(liquidated,unitsValue(m.holdings[c.id],oldPrice(s,c.id),'round'));m.holdings[c.id]=0;}else m.holdings[c.id]=unitOut(atoms);}
 s.cash=M.add(s.cash,recovered,liquidated);m.adjustment={recovered,liquidated,year:s.year};return m.adjustment;
}
function valid(s,num,str){
 if(s.people.some(p=>!num(p.popularity,0,100)||!num(p.talent,0,100)||!Object.prototype.hasOwnProperty.call(careers,p.career)))return false;
 const p=s.politics;if(!p||!num(p.experience,0,1000)||!num(p.lastElectionYear,-1,s.year)||!Number.isInteger(p.lastElectionYear)||!num(p.policyYear,-1,s.year)||!Number.isInteger(p.policyYear)||!Array.isArray(p.elections)||p.elections.length>30)return false;
 if(p.elections.some(e=>!e||!offices.some(d=>d.id===e.id)||!num(e.year,0,s.year)||!num(e.votes,2,98)||typeof e.won!=='boolean'||!str(e.opponent,60)))return false;
 if(p.office&&(!offices.some(d=>d.id===p.office.id)||!num(p.office.remaining,1,8)||!Number.isInteger(p.office.remaining)||!num(p.office.approval,0,100)))return false;
 if(p.campaign&&(!offices.some(d=>d.id===p.campaign.id)||!['base','ampla'].includes(p.campaign.budget)||!num(p.campaign.effort,0,6)||!Number.isInteger(p.campaign.effort)||!num(p.campaign.year,0,s.year)))return false;
 if(p.office&&(p.campaign||s.job||s.retired||!s.alive||s.prison))return false;if(p.campaign&&(!s.alive||s.prison))return false;
 const m=s.market;if(!m||!num(m.seed,1,4294967295)||!Number.isInteger(m.seed)||!m.holdings||Object.keys(m.holdings).length!==coins.length||!m.collapsed||Array.isArray(m.collapsed)||Object.entries(m.collapsed).some(([id,c])=>!coins.some(x=>x.id===id)||!c||!num(c.age,0,150)||!num(c.year,0,s.year))||!m.adjustment||!M.valid(m.adjustment.recovered)||!M.valid(m.adjustment.liquidated)||!num(m.adjustment.year,0,s.year)||!Array.isArray(m.trades)||m.trades.length>40)return false;
 try{if(coins.some(c=>unitAtoms(m.holdings[c.id])>BigInt(supply(s,c.id))*ATOMS||(!m.collapsed[c.id]&&unitAtoms(m.holdings[c.id])>BigInt(supply(s,c.id))*ATOMS/2n)))return false;}catch(e){return false;}
 return !m.trades.some(t=>!t||!coins.some(c=>c.id===t.id)||!['buy','sell','sellAll'].includes(t.operation)||!num(t.age,0,150)||!num(t.price,0,1e9)||!M.valid(t.total)||!['number','string'].includes(typeof t.units)||!Number.isFinite(Number(t.units))||Number(t.units)<0||Number(t.units)>1e12);
}
const W={M,supply,unitAtoms,unitOut,unitsValue,migrateMarket,oldPrice,NEW_SKILLS,careers,socialDefaults,careerTitle,influence,evolveFriend,circles,maintenance,trainingFactor,projectFactor,battle,offices,policies,emptyPolitics,campaignQuote,electionForecast,policyStrength,coins,coinInfo,emptyMarket,profile,price,cryptoWorth,tradeQuote,valid};
if(typeof module!=='undefined'&&module.exports)module.exports=W;else root.LifeWorld=W;
})(typeof globalThis!=='undefined'?globalThis:this);
