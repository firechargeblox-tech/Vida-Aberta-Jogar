/* Vida Aberta 0.12.0: assets exclusivos do jogo, disponíveis offline após a primeira visita. */
const CACHE = 'vida-aberta-pwa-v0.12.0-1';
const ASSETS = ["./app.js", "./apple-touch-icon.png", "./citizens.js", "./civic.js", "./data.js", "./engine.js", "./enterprises.js", "./events.js", "./freedom-ui.js", "./freedom.js", "./funding.js", "./government.js", "./icon-192.png", "./icon-512.png", "./index.html", "./justice.js", "./manifest.webmanifest", "./money.js", "./operations.js", "./orbit.js", "./policy-core.js", "./president-ui.js", "./reserves.js", "./simulation.js", "./statecraft.js", "./storage.js", "./stories.js", "./style.css", "./systems.js", "./timelines.js", "./world.js"];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(names => Promise.all(names.filter(name => name.startsWith('vida-aberta-pwa-') && name !== CACHE).map(name => caches.delete(name)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin || event.request.method !== 'GET' || !url.pathname.startsWith(new URL(self.registration.scope).pathname)) return;
  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request)));
});
