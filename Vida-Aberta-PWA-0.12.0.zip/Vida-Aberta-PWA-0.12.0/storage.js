(function(root){
'use strict';
const KEY='vida-aberta-save-v1',BAK=KEY+'-backup',E=root.LifeEngine;
const native=()=>root.Android&&typeof root.Android.load==='function';
const api=name=>native()&&typeof root.Android[name]==='function';
function localGet(k){try{return root.localStorage.getItem(k)||'';}catch(e){return '';}}
function decode(raw){if(typeof raw!=='string')return null;if(raw.charCodeAt(0)===0xFEFF)raw=raw.slice(1);if(!raw||raw.length>E.D.MAX_SAVE)return null;try{return E.validate(JSON.parse(raw));}catch(e){return null;}}
function load(){
 const sources=[];if(native()){try{sources.push({raw:root.Android.load(),backup:false},{raw:root.Android.loadBackup(),backup:true});}catch(e){}}
 sources.push({raw:localGet(KEY),backup:false},{raw:localGet(BAK),backup:true});
 for(const x of sources){const state=decode(x.raw);if(state)return {state,recovered:x.backup};}
 return {state:null,recovered:false,corrupted:sources.some(x=>!!x.raw)};
}
function save(s){const raw=JSON.stringify(s);if(raw.length>E.D.MAX_SAVE)return false;let success=false;
 if(native()){try{success=root.Android.save(raw)!==false;}catch(e){}}
 try{const old=root.localStorage.getItem(KEY);if(old&&decode(old))root.localStorage.setItem(BAK,old);root.localStorage.setItem(KEY,raw);success=true;}catch(e){}
 return success;
}
function serialize(s){
 try{
  if(!s||s.game!=='vida-aberta'||!Number.isInteger(s.version)||s.version<1||s.version>12)return {ok:false,msg:'Não há um progresso disponível para copiar.'};
  const raw=JSON.stringify(s);
  if(raw.length>E.D.MAX_SAVE)return {ok:false,msg:'O progresso excedeu o limite de tamanho da cópia. Sua vida continua aberta no jogo.'};
  return {ok:true,raw};
 }catch(e){return {ok:false,msg:'Não foi possível preparar a cópia do progresso. Tente novamente.'};}
}
function nativeTransfer(method,raw){
 try{const reply=root.Android[method](raw);if(reply===false)return {ok:false,msg:'O aparelho não iniciou a cópia. Tente novamente ou escolha a outra opção.'};
  if(typeof reply==='string'&&reply)return {ok:false,msg:reply};
  return {ok:true,mode:'native'};
 }catch(e){return {ok:false,msg:'Não foi possível iniciar a cópia neste aparelho. Tente a outra opção.'};}
}
function exportSave(s){
 const encoded=serialize(s);if(!encoded.ok)return encoded;
 if(api('exportSave'))return nativeTransfer('exportSave',encoded.raw);
 if(native())return {ok:false,msg:'A exportação de arquivo não está disponível nesta instalação.'};
 let url=null;
 try{
  if(!root.URL||typeof root.URL.createObjectURL!=='function')return {ok:false,msg:'Este navegador não permite baixar a cópia do progresso.'};
  const blob=new root.Blob([encoded.raw],{type:'application/json;charset=utf-8'});url=root.URL.createObjectURL(blob);
  const a=root.document.createElement('a');a.href=url;a.download='Vida-Aberta-'+String(s.name||'progresso').replace(/[^a-z0-9]/gi,'-')+'-'+s.age+'-anos.json';
  root.document.body.appendChild(a);a.click();a.remove();const created=url;
  root.setTimeout(()=>root.URL.revokeObjectURL(created),2000);return {ok:true,mode:'download'};
 }catch(e){if(url)root.URL.revokeObjectURL(url);return {ok:false,msg:'Não foi possível iniciar o download. Tente novamente.'};}
}
function canShare(){return !!api('shareSave');}
function shareSave(s){const encoded=serialize(s);if(!encoded.ok)return encoded;if(!canShare())return {ok:false,msg:'O compartilhamento não está disponível. Use Exportar progresso.'};return nativeTransfer('shareSave',encoded.raw);}
root.LifeStore={load,save,decode,serialize,exportSave,shareSave,canShare,native,KEY,BAK};
})(typeof globalThis!=='undefined'?globalThis:this);
