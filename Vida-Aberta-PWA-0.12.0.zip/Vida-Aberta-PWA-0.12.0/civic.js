(function(root){
'use strict';
const Justice=typeof module!=='undefined'&&module.exports?require('./justice.js'):root.LifeJustice;
const M=typeof module!=='undefined'&&module.exports?require('./money.js'):root.LifeMoney;
// Todos os valores são regras de uma economia fictícia, sem conexão com dados reais.
const own=(o,k)=>Object.prototype.hasOwnProperty.call(o,k),clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n)),money=n=>Math.round(clamp(n,0,1e15));
const sectorNames={infraestrutura:'Infraestrutura',educacao:'Educação',saude:'Saúde',seguranca:'Segurança',economia:'Economia e ciência',ambiente:'Ambiente'};
const technologies={
 duravel:{name:'Estruturas duráveis e reparáveis',capital:1.6,maintenance:.55,capacity:1.05,desc:'Mais implantação; menos desgaste e manutenção.'},
 rapido:{name:'Entrega rápida e materiais frágeis',capital:.55,maintenance:1.9,capacity:.8,desc:'Barato para inaugurar; falhas e manutenção maiores.'},
 mesh:{name:'Rádio mesh e mensagens de socorro',capital:.5,maintenance:.5,capacity:1,desc:'Comunicação de emergência barata; não substitui banda larga.'},
 fibra:{name:'Fibra e acesso compartilhado',capital:1.4,maintenance:1,capacity:1.2,desc:'Mais capacidade digital; exige infraestrutura.'},
 solar:{name:'Energia solar e reserva local',capital:1.5,maintenance:.7,capacity:1.05,desc:'Diminui a parcela de energia; conserva equipamentos e baterias.'},
 drones:{name:'Drones e sensores de campo',capital:1.3,maintenance:.85,capacity:1.35,desc:'Melhora cobertura; requer operadores e manutenção.'},
 ia:{name:'IA focada com supervisão',capital:1.2,maintenance:.85,capacity:1.5,desc:'Amplia produtividade; depende de conexão e supervisão humana.'},
 video:{name:'Videoaulas e acervos offline',capital:.8,maintenance:.7,capacity:1.3,desc:'Conteúdo reutilizável, fortalecido pela pesquisa de videoaulas.'},
 presencial:{name:'Atendimento por equipes presenciais',capital:.8,maintenance:1.5,capacity:1.2,desc:'Acesso assistido; folha recorrente elevada.'},
 improvisado:{name:'Equipamentos sem certificação',capital:.35,maintenance:2,capacity:.6,desc:'Implantação barata; risco elevado de interrupções e acidentes.'}
};
const operators={publico:{name:'Equipe pública',cost:1,quality:1},empresa:{name:'Empresa por concorrência',cost:.85,quality:1},cooperativa:{name:'Cooperativa',cost:.9,quality:1},comunidade:{name:'Associação comunitária',cost:.7,quality:.85},misto:{name:'Rede de prestadores concorrentes',cost:.95,quality:1.15},favorecido:{name:'Fornecedor favorecido sem disputa',cost:1.35,quality:.65}};
const funding={impostos:'Tesouro e impostos',tarifa:'Cobrança por uso, sem complemento',voluntario:'Assinaturas voluntárias, sem complemento',concessao:'Concessão com exploração comercial',fundo:'Rendimento de fundo patrimonial',misto:'Tarifa com complemento público'};
const partySystems={livres:'Partidos e candidaturas livres',coalizao:'Coalizões com negociação',unico:'Partido único e barreira a opositores'};
const decisions={executivo:'Decisão direta do governante',referendo:'Reformas submetidas a referendo'};
const orgTypes={fundacao:'Fundação de serviços',associacao:'Associação comunitária',partido:'Partido político'};
function initialize(g,seed=1){g.civic={seed:(seed>>>0)||1,seq:0,programs:[],taxRules:{},fund:0,institutions:{autonomy:0,termYears:4,maxTerms:0,parties:'livres',decision:'executivo'},justice:{...Justice.defaults(),multiplier:2,years:3,enforcement:50,arbitration:false,work:false,violent:'prisao'},automatic:{enabled:false,debt:50,reserve:25,tax:25,reserveTarget:50,staff:false,capacity:100,minimum:50,maximum:150}};}
function emptyLife(){return {seq:0,organizations:[]};}
function hash(t){let h=2166136261;for(const c of t){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}h^=h>>>16;h=Math.imul(h,0x85ebca6b);h^=h>>>13;h=Math.imul(h,0xc2b2ae35);h^=h>>>16;return (h>>>0)/4294967296;}
function taxDefault(rate){return {progressive:false,allowance:0,deduction:0,band1:36000,band2:120000,rate1:rate,rate2:rate,rate3:rate,sector:'todos',relief:0};}
function taxBill(g,id,amount,sector='todos'){
 const rate=g.taxes[id]||0,r=g.civic&&g.civic.taxRules[id];if(!r)return M.percent(amount,rate);
 const base=M.percent(M.max(0,M.sub(amount,r.allowance)),100-r.deduction);let due;
 if(r.progressive)due=M.add(M.percent(M.min(base,r.band1),r.rate1),M.percent(M.max(0,M.sub(M.min(base,r.band2),r.band1)),r.rate2),M.percent(M.max(0,M.sub(base,r.band2)),r.rate3));
 else due=M.percent(base,rate);
 return r.sector!=='todos'&&r.sector===sector?M.percent(due,100-r.relief):due;
}
function taxAverage(g,id,rate,average){
 if(!g.civic||!g.civic.taxRules[id])return rate;
 // Distribuição sintética fixa; isenções de renda não são aplicadas ao PIB inteiro.
 const groups=[[.4,.35],[1,.45],[3,.2]],sectors=['servicos','comercio','tecnologia','industria'],result=groups.reduce((sum,[multiple,weight])=>sum+sectors.reduce((n,sector)=>n+taxBill(g,id,average*multiple,sector)/(Math.max(1,average*multiple))*100,0)/sectors.length*weight,0);
 return clamp(result,0,100);
}
function programQuote(g,p){
 const ts=p.technologies.map(id=>technologies[id]),capital=ts.reduce((n,t)=>n+t.capital,0)/ts.length,maint=ts.reduce((n,t)=>n+t.maintenance,0)/ts.length;
 const target=p.target,ready=p.invested>=target,reach=p.coverage/100*p.operating/100,operator=operators[p.operator],team=.25+.75*p.staff/100;
 const gross=ready?money((g.gdp*.0012*reach*maint*operator.cost*team+p.target*.004)*(p.audit?1.08:1)):0;
 const affordability=clamp((g.gdp/g.population)/Math.max(1,p.fee*12),.05,1),potential=money(g.population*reach*p.fee*affordability),trust=g.metrics.confianca/100;
 let external=0,yieldUsed=0;
 if(p.funding==='tarifa'||p.funding==='misto')external=Math.min(gross,potential);
 if(p.funding==='voluntario')external=Math.min(gross,money(potential*.25*trust));
 if(p.funding==='concessao')external=Math.min(gross,money(gross*.7*g.metrics.economia/100));
 if(p.funding==='fundo'){yieldUsed=Math.min(gross,money(p.fund*.04));external=yieldUsed;}
 const needsPublic=['impostos','misto','concessao'].includes(p.funding),publicCost=needsPublic?Math.max(0,gross-external):0,work=Math.min(p.annual,Math.max(0,target-p.invested));
 let productivity=ts.reduce((n,t)=>n+t.capacity,0)/ts.length;
 if(p.technologies.includes('ia'))productivity*=g.metrics.conectividade>=45&&p.staff>=25?1.25:.4;
 if(p.technologies.includes('video')&&p.sector==='educacao')productivity*=1+Math.log1p(g.research.videoaulas.knowledge)*.08;
 const capacity=clamp(p.staff/100*productivity,0,1.8),quality=clamp(capacity*operator.quality*p.condition/100*(1+g.civic.institutions.autonomy/100*(g.metrics.educacao-50)/250),0,1.3);
 return {target,capital,ready,gross,external,publicCost,work,total:publicCost+work,capacity,quality,yieldUsed,affordability,people:Math.round(g.population*reach)};
}
function targetFor(g,p){const average=p.technologies.reduce((n,id)=>n+technologies[id].capital,0)/p.technologies.length;return Math.max(1,money(g.gdp*.002*p.coverage/100*average));}
function plan(g){const items=g.civic.programs.filter(p=>!p.closed).map(p=>({id:p.id,...programQuote(g,p)}));return {items,total:items.reduce((n,x)=>n+x.total,0),work:items.reduce((n,x)=>n+x.work,0),operation:items.reduce((n,x)=>n+x.publicCost,0)};}
function annual(s,g,paid,notes,quotes=plan(g).items){
 const results=[];let education=0;
 for(const p of g.civic.programs){if(p.closed)continue;const q=quotes.find(x=>x.id===p.id)||programQuote(g,p),work=paid['civicwork:'+p.id]||0,service=paid['civicservice:'+p.id]||0;p.invested=Math.min(p.target,p.invested+work);const fundYield=money(p.fund*.04);p.fund=money(p.fund+fundYield-(q.ready?q.yieldUsed:0));
  if(!q.ready){if(p.invested>=p.target){p.annual=0;notes.push(p.name+': implantação concluída; operação começa no próximo ano.');}results.push({id:p.id,name:p.name,work,service,external:0,gross:0,coverage:0,quality:0,failed:false,condition:p.condition});continue;}
  const delivery=q.gross?clamp((service+q.external)/q.gross):0;
  const risk=clamp(.025+(p.technologies.includes('improvisado')?.35:0)+(p.technologies.includes('rapido')?.12:0)+(p.operator==='favorecido'?.25:0)+(p.audit?-.02:.08)+(1-delivery)*.2,0,.8),failed=p.operating>0&&hash(g.civic.seed+'/'+g.id+'/'+p.id+'/'+s.year)<risk,output=delivery*q.quality*(failed?.2:1)*p.coverage/100*p.operating/100;
  p.condition=clamp(p.condition-(1-delivery)*12-(failed?15:0)+(delivery>.95&&p.audit?2:0),0,100);
  const add=(id,delta)=>{g.metrics[id]=clamp(g.metrics[id]+delta,0,100);};add(p.sector,output*5);add('igualdade',output*(p.funding==='tarifa'?-3:1.5));
  if(p.technologies.includes('mesh')){add('conectividade',output*2);add('seguranca',output);}
  if(p.technologies.includes('fibra'))add('conectividade',output*4);
  if(p.technologies.includes('solar'))add('ambiente',output*2);
  if(p.sector==='educacao')education+=output;
  if(p.operator==='favorecido'){add('corrupcao',3*delivery);add('confianca',-2*delivery);}
  if(failed){add(p.sector,-2*p.coverage/100);add('confianca',-2);notes.push(p.name+': falha de operação; atendimento reduzido e condição prejudicada. Rever equipamentos, fiscalização e recursos pode evitar reincidência.');}
  if(delivery<.95)notes.push(p.name+': apenas '+Math.round(delivery*100)+'% do custeio coberto. Assinaturas, tarifas ou aportes foram insuficientes.');
  if(!p.operating)notes.push(p.name+': operação suspensa; nenhum atendimento entregue.');
  p.last={year:s.year,delivery,quality:q.quality,failed};
  results.push({id:p.id,name:p.name,work,service,external:q.external,gross:q.gross,coverage:delivery,quality:q.quality,failed,condition:p.condition});
 }
 const i=g.civic.institutions;
 if(i.autonomy){const support=g.metrics.educacao/100,delta=i.autonomy/100;g.metrics.confianca=clamp(g.metrics.confianca+delta*(support-.4)*2,0,100);g.metrics.igualdade=clamp(g.metrics.igualdade-delta*(1-support),0,100);notes.push('Autonomia local em '+i.autonomy+'%: decisões e prestadores regionais; diferenças de capacidade afetam o acesso.');}
 if(i.parties==='coalizao'){g.metrics.confianca=clamp(g.metrics.confianca+.5,0,100);notes.push('A coalizão manteve negociação entre grupos, com custo adicional de coordenação.');}
 if(i.parties==='unico'){g.metrics.liberdade=clamp(g.metrics.liberdade-30,0,100);g.metrics.corrupcao=clamp(g.metrics.corrupcao+15,0,100);g.metrics.confianca=clamp(g.metrics.confianca-6,0,100);notes.push('A barreira a opositores reduziu a liberdade, a fiscalização e a confiança pública.');}
 return {results,education};
}
function automatic(s,g,revenue,notes){
 const a=g.civic.automatic,report={debt:0,reserve:0,taxCut:0,fundYield:0,staff:[]};
 report.fundYield=money(g.civic.fund*.04);g.civic.fund=money(g.civic.fund+report.fundYield);
 if(!a.enabled)return report;
 // Só o excedente do ano, sem consumir caixa anterior nem crédito novo.
 const surplus=Math.max(0,Math.min(g.treasury,revenue-(g.reports[0]?g.reports[0].executed:revenue)));
 const base=Number.isFinite(surplus)?surplus:0;report.debt=Math.min(g.debt,money(base*a.debt/100));g.debt-=report.debt;g.treasury-=report.debt;
 report.reserve=Math.min(Math.max(0,money(revenue*a.reserveTarget/100)-g.civic.fund),money(base*a.reserve/100),g.treasury);g.treasury-=report.reserve;g.civic.fund+=report.reserve;
 if(base>0&&a.tax>0){report.taxCut=clamp(base/Math.max(1,revenue)*a.tax/100*.15,0,.15);for(const id of Object.keys(g.taxes)){g.taxes[id]=Math.round(g.taxes[id]*(1-report.taxCut)*100)/100;const r=g.civic.taxRules[id];if(r)for(const key of ['rate1','rate2','rate3'])r[key]=Math.round(r[key]*(1-report.taxCut)*100)/100;}notes.push('Regra de excedente: dívida amortizada, reserva patrimonial e alíquotas ajustadas apenas após despesas.');}
 return report;
}
function annualOrganizations(s,log){let spent=0;for(const o of s.civicLife.organizations){const amount=Number(M.min(o.annual,M.max(0,s.cash)));s.cash=M.sub(s.cash,amount);spent=M.add(spent,amount);o.spent=M.add(o.spent,amount);if(amount<=0)continue;const strength=clamp(Math.log1p(amount/1000),0,4);s.fame=clamp(s.fame+strength,0,100);s.reputation=clamp(s.reputation+strength*.5,0,100);s.politics.experience=clamp(s.politics.experience+strength*.1,0,1000);const g=s.governments.prefeito||s.governments.governador||s.governments.presidente;if(g&&o.type!=='partido')g.metrics[o.sector]=clamp(g.metrics[o.sector]+strength*.3,0,100);log(s,o.name+': R$ '+amount.toLocaleString('pt-BR')+' aplicados; sua atuação civil ganhou alcance.','🤝','politica');}return spent;}
function termRules(s,id){const g=s.governments[id];return g&&g.civic?g.civic.institutions:{termYears:4,maxTerms:0,parties:'livres'};}
function electionBlock(s,id){const i=termRules(s,id);if(!i.maxTerms)return '';const wins=s.politics.elections.filter(e=>e.id===id&&e.won).length;return wins>=i.maxTerms?'O limite vigente de '+i.maxTerms+' mandato(s) neste cargo foi atingido.':'';}
const actionTypes=['saveCivicProgram','setCivicProgram','fundCivicProgram','reformInstitutions','setJusticeRules','setTaxRules','setPublicAutomation','publicReserveMove','createOrganization','setOrganization'];
function act(s,g,type,p,charge){
 const fail=msg=>({ok:false,msg});let msg='',err;
 if(type==='createOrganization'||type==='setOrganization'){
  if(type==='createOrganization'){if(!own(orgTypes,p.kind)||!own(sectorNames,p.sector)||typeof p.name!=='string'||!p.name.trim()||p.name.trim().length>60||s.civicLife.organizations.length>=12)return fail('Escolha tipo, área e nome de até 60 caracteres; há espaço para 12 organizações.');const n=Number(p.annual);if(!Number.isFinite(n)||n<0||n>1e15||s.cash<500)return fail('Informe um aporte anual válido. A fundação usa R$ 500 do seu caixa.');if((err=charge()))return fail(err);s.cash=M.sub(s.cash,500);s.civicLife.seq++;s.civicLife.organizations.push({id:'org'+s.civicLife.seq,name:p.name.trim(),type:p.kind,sector:p.sector,annual:money(n),spent:500});msg='Organização criada. Seu aporte anual só usa dinheiro pessoal disponível; não contrai dívida automática.';
  }else{const o=s.civicLife.organizations.find(x=>x.id===p.id),n=Number(p.annual);if(!o||!Number.isFinite(n)||n<0||n>1e15)return fail('Escolha a organização e um aporte anual válido.');if((err=charge()))return fail(err);o.annual=money(n);msg='Aporte pessoal anual atualizado; zero pausa a atuação sem apagar a organização.';}
  return {ok:true,msg};
 }
 if(!g)return fail('Você precisa estar em um mandato para mudar o governo.');
 if(type==='saveCivicProgram'){
  const old=p.id?g.civic.programs.find(x=>x.id===p.id):null;if(p.id&&!old)return fail('Programa não encontrado.');
  const coverage=Number(p.coverage),staff=Number(p.staff),annual=Number(p.annual),fee=Number(p.fee);
  if(!own(sectorNames,p.sector)||!own(operators,p.operator)||!own(funding,p.funding)||typeof p.name!=='string'||!p.name.trim()||p.name.trim().length>60||!Array.isArray(p.technologies)||!p.technologies.length||p.technologies.length>4||new Set(p.technologies).size!==p.technologies.length||p.technologies.some(id=>!own(technologies,id))||typeof p.audit!=='boolean'||![coverage,staff,annual,fee].every(Number.isFinite)||coverage<1||coverage>100||staff<0||staff>200||annual<0||annual>1e15||fee<0||fee>1e6)return fail('Revise nome, área, alcance de 1% a 100%, equipe de 0% a 200% e uma a quatro tecnologias.');
  if(!old&&g.civic.programs.length>=64)return fail('Seu governo já possui 64 programas registrados.');
  const config={name:p.name.trim(),sector:p.sector,coverage,staff,operator:p.operator,funding:p.funding,technologies:p.technologies.slice(),audit:p.audit,annual:money(annual),fee:money(fee)};
  const target=targetFor(g,config),changed=old&&['sector','coverage','technologies'].some(k=>JSON.stringify(old[k])!==JSON.stringify(config[k]));
  if((err=charge()))return fail(err);
  if(old){const changeOperator=old.operator!==config.operator;Object.assign(old,config);if(changed||changeOperator){old.target=money(Math.max(old.target,target)+old.target*(changeOperator?.1:.15));old.condition=Math.min(old.condition,90);}msg='Programa revisado. Obras e fundos anteriores permanecem; mudança de estrutura ou prestador exige novo investimento.';}
  else{g.civic.seq++;g.civic.programs.push({id:'livre'+g.civic.seq,...config,target,invested:0,operating:100,condition:100,fund:0,closed:false,last:null});msg='Programa criado. Implantação e custeio entram no plano anual; nenhuma despesa foi retirada do caixa pessoal.';}
 }else if(type==='setCivicProgram'){
  const item=g.civic.programs.find(x=>x.id===p.id);if(!item)return fail('Programa não encontrado.');
  if(p.mode==='vender'){if(item.closed)return fail('O programa já foi encerrado.');if((err=charge()))return fail(err);const recovered=money(item.invested*item.condition/100*.35+item.fund);g.treasury=money(g.treasury+recovered);item.closed=true;item.annual=0;item.operating=0;item.fund=0;msg='Programa encerrado: ativos vendidos por 35% do valor conservado e fundo devolvido ao tesouro. Reconstruir exige um novo programa.';
  }else{const n=Number(p.percent);if(item.closed||!Number.isFinite(n)||n<0||n>100)return fail('Escolha operação entre 0% e 100% para um programa existente.');if((err=charge()))return fail(err);item.operating=n;msg='Operação em '+n+'%. Cobertura e custeio acompanham a decisão; a estrutura permanece.';}
 }else if(type==='fundCivicProgram'){
  const item=g.civic.programs.find(x=>x.id===p.id),amount=money(Number(p.amount));if(!item||item.closed||!Number.isFinite(Number(p.amount))||Number(p.amount)<1||Number(p.amount)>1e15||!['pessoal','publico'].includes(p.source)||!['obra','fundo'].includes(p.destination))return fail('Escolha origem, destino e um valor positivo válido.');if(amount>(p.source==='pessoal'?s.cash:g.treasury))return fail('O caixa escolhido não cobre o aporte.');if(p.destination==='fundo'&&amount+item.fund>1e15)return fail('O fundo deste programa comporta até R$ 1 quadrilhão. Use Custeio pessoal para pagar despesas maiores diretamente.');if(p.destination==='obra'&&amount>item.target-item.invested)return fail('O aporte supera o custo que falta para implantar.');if((err=charge()))return fail(err);if(p.source==='pessoal')s.cash=M.sub(s.cash,amount);else g.treasury-=amount;if(p.destination==='obra')item.invested+=amount;else item.fund=money(item.fund+amount);msg='Aporte aplicado ao '+(p.destination==='obra'?'patrimônio físico':'fundo patrimonial')+'. O recurso passa a pertencer ao programa, sem reembolso pessoal.';
 }else if(type==='publicReserveMove'){
  const amount=money(Number(p.amount));if(!Number.isFinite(Number(p.amount))||Number(p.amount)<1||Number(p.amount)>1e15||!['aplicar','resgatar'].includes(p.mode))return fail('Informe um valor positivo para aplicar ou resgatar a reserva.');if(amount>(p.mode==='aplicar'?g.treasury:g.civic.fund))return fail('O saldo disponível não cobre a transferência.');if((err=charge()))return fail(err);if(p.mode==='aplicar'){g.treasury-=amount;g.civic.fund=money(g.civic.fund+amount);}else{g.civic.fund-=amount;g.treasury=money(g.treasury+amount);}msg='Reserva pública transferida. Nenhum valor passou pelo caixa pessoal.';
 }else if(type==='setTaxRules'){
  const r={progressive:p.progressive,allowance:Number(p.allowance),deduction:Number(p.deduction),band1:Number(p.band1),band2:Number(p.band2),rate1:Number(p.rate1),rate2:Number(p.rate2),rate3:Number(p.rate3),sector:p.sector,relief:Number(p.relief)};
  if(!own(g.taxes,p.id)||!validTax(r,(n,a,b)=>Number.isFinite(n)&&n>=a&&n<=b)||r.progressive&&!['irpf','irpj'].includes(p.id))return fail('Revise faixas, alíquotas, deduções e competência do tributo. Faixas progressivas estão disponíveis para IRPF e IRPJ.');if((err=charge()))return fail(err);g.civic.taxRules[p.id]=r;msg='Regras tributárias atualizadas. Isenções e descontos podem reduzir a receita; a previsão já mostra o custo da transição.';
 }else if(type==='setJusticeRules'){
  if(g.id!=='presidente')return fail('A reforma de justiça é nacional nesta simulação.');const r={...g.civic.justice,multiplier:Number(p.multiplier),years:Number(p.years),enforcement:Number(p.enforcement),arbitration:p.arbitration,work:p.work,violent:p.violent};for(const k of ['model','proof','review','protectedIncome','compensationAnnual'])if(own(p,k))r[k]=['proof','protectedIncome','compensationAnnual'].includes(k)?Number(p[k]):p[k];if(r.model==='reparadora')r.multiplier=2;if(!validJustice(r,(n,a,b)=>Number.isFinite(n)&&n>=a&&n<=b))return fail('Revise multiplicador de 1 a 5, prazo de 1 a 10 anos e esforço de cobrança de 0% a 100%.');if((err=charge()))return fail(err);g.civic.justice=r;if(r.model==='reparadora'&&!g.laws.includes('restituicao_dobrada'))g.laws.push('restituicao_dobrada');msg=r.model==='reparadora'?'Justiça reparadora ativada: dano patrimonial 2×, acusação deliberadamente falsa comprovada 4×. Denúncia de boa-fé sem prova não gera obrigação. Revisão e indenizações dependem do custeio; saldos anteriores permanecem.':'Regras anteriores de restituição selecionadas. A lei de restituição controla novos créditos; obrigações e revisões anteriores permanecem.';
 }else if(type==='reformInstitutions'){
  const i={autonomy:Number(p.autonomy),termYears:Number(p.termYears),maxTerms:Number(p.maxTerms),parties:p.parties,decision:p.decision};if(!validInstitutions(i,(n,a,b)=>Number.isFinite(n)&&n>=a&&n<=b))return fail('Revise autonomia, mandatos de 2 a 8 anos, limite de 0 a 10 mandatos e regras de participação.');
  const vote=g.civic.institutions.decision==='referendo'||p.referendum===true,cost=vote?money(g.gdp*.00002):0;if(p.personal===true?M.cmp(s.cash,cost)<0:cost>g.treasury)return fail('Não há caixa público para organizar o referendo.');if((err=charge()))return fail(err);if(p.personal===true)s.cash=M.sub(s.cash,cost);else g.treasury-=cost;
  const support=clamp(20+s.politics.office.approval*.45+s.reputation*.15+(i.autonomy>0?5:0)-(i.parties==='unico'?30:0)+(hash(g.id+'/reforma/'+s.year+'/'+JSON.stringify(i))-.5)*10,2,98);
  if(vote&&support<=50)msg='Reforma rejeitada no referendo, com '+support.toFixed(1)+'% de apoio. O custo da consulta foi pago e as regras anteriores continuam.';
  else{g.civic.institutions=i;msg='Reforma '+(vote?'aprovada com '+support.toFixed(1)+'% de apoio':'promulgada')+'. Duração e limite de mandatos valem para futuras eleições, sem prolongar o mandato atual.';}
 }else if(type==='setPublicAutomation'){
  const a={enabled:p.enabled,debt:Number(p.debt),reserve:Number(p.reserve),tax:Number(p.tax),reserveTarget:Number(p.reserveTarget),staff:p.staff,capacity:Number(p.capacity),minimum:Number(p.minimum),maximum:Number(p.maximum)};if(!validAutomatic(a,(n,lo,hi)=>Number.isFinite(n)&&n>=lo&&n<=hi))return fail('As parcelas do excedente devem somar 100%. Revise os limites de equipe e reserva.');if((err=charge()))return fail(err);g.civic.automatic=a;msg='Regras automáticas salvas. Serão aplicadas após a execução anual, usando excedente real e limites de equipe escolhidos.';
 }else return fail('Ação cívica desconhecida.');
 return {ok:true,msg};
}
function validTax(r,num){return !!r&&typeof r.progressive==='boolean'&&num(r.allowance,0,1e12)&&num(r.deduction,0,100)&&num(r.band1,1,1e12)&&num(r.band2,r.band1+1,1e12)&&['rate1','rate2','rate3','relief'].every(k=>num(r[k],0,100))&&['todos','servicos','comercio','tecnologia','industria'].includes(r.sector);}
function validJustice(r,num){return Justice.rulesValid(r,num)&&num(r.multiplier,1,5)&&Number.isInteger(r.years)&&num(r.years,1,10)&&num(r.enforcement,0,100)&&typeof r.arbitration==='boolean'&&typeof r.work==='boolean'&&['prisao','reabilitacao','repressao'].includes(r.violent);}
function validInstitutions(i,num){return !!i&&num(i.autonomy,0,100)&&Number.isInteger(i.termYears)&&num(i.termYears,2,8)&&Number.isInteger(i.maxTerms)&&num(i.maxTerms,0,10)&&own(partySystems,i.parties)&&own(decisions,i.decision);}
function validAutomatic(a,num){return !!a&&typeof a.enabled==='boolean'&&typeof a.staff==='boolean'&&['debt','reserve','tax'].every(k=>num(a[k],0,100))&&Math.abs(a.debt+a.reserve+a.tax-100)<.001&&num(a.reserveTarget,0,500)&&num(a.capacity,0,200)&&num(a.minimum,0,500)&&num(a.maximum,a.minimum,500);}
function validLife(s,num,str){const c=s.civicLife;return !!c&&Number.isInteger(c.seq)&&num(c.seq,0,1e8)&&Array.isArray(c.organizations)&&c.organizations.length<=12&&new Set(c.organizations.map(o=>o.id)).size===c.organizations.length&&c.organizations.every(o=>o&&/^org[1-9]\d*$/.test(o.id)&&Number(o.id.slice(3))<=c.seq&&str(o.name,60)&&o.name.trim()&&own(orgTypes,o.type)&&own(sectorNames,o.sector)&&num(o.annual,0,1e15)&&M.valid(o.spent));}
function valid(g,num,str){
 const c=g.civic;if(!c||!Number.isInteger(c.seed)||!num(c.seed,1,4294967295)||!validInstitutions(c.institutions,num)||!validJustice(c.justice,num)||!validAutomatic(c.automatic,num)||!Number.isInteger(c.seq)||!num(c.seq,0,1e8)||!M.valid(c.fund)||!c.taxRules||typeof c.taxRules!=='object'||Array.isArray(c.taxRules)||Object.entries(c.taxRules).some(([id,r])=>!own(g.taxes,id)||!validTax(r,num)||r.progressive&&!['irpf','irpj'].includes(id)))return false;
 if(!Array.isArray(c.programs)||c.programs.length>64||new Set(c.programs.map(p=>p&&p.id)).size!==c.programs.length)return false;
 return c.programs.every(p=>p&&/^livre[1-9]\d*$/.test(p.id)&&Number(p.id.slice(5))<=c.seq&&str(p.name,60)&&p.name.trim()&&own(sectorNames,p.sector)&&num(p.coverage,1,100)&&num(p.staff,0,200)&&own(operators,p.operator)&&own(funding,p.funding)&&Array.isArray(p.technologies)&&p.technologies.length>=1&&p.technologies.length<=4&&new Set(p.technologies).size===p.technologies.length&&p.technologies.every(id=>own(technologies,id))&&typeof p.audit==='boolean'&&typeof p.closed==='boolean'&&num(p.annual,0,1e15)&&num(p.fee,0,1e6)&&num(p.target,1,1e15)&&num(p.invested,0,p.target)&&num(p.operating,0,100)&&num(p.condition,0,100)&&num(p.fund,0,1e15)&&(p.last===null||p.last&&num(p.last.year,0,10000)&&num(p.last.delivery,0,1)&&num(p.last.quality,0,1.3)&&typeof p.last.failed==='boolean'));
}
const C={sectorNames,technologies,operators,funding,partySystems,decisions,orgTypes,initialize,emptyLife,validJustice,taxDefault,taxBill,taxAverage,programQuote,targetFor,plan,annual,automatic,annualOrganizations,termRules,electionBlock,actionTypes,act,valid,validLife};
if(typeof module!=='undefined'&&module.exports)module.exports=C;else root.LifeCivic=C;
})(typeof globalThis!=='undefined'?globalThis:this);
