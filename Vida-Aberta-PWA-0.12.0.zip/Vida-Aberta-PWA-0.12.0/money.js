(function(root){
'use strict';
// Reais inteiros exatos. Números seguros continuam números; saldos maiores usam
// strings decimais no JSON. BigInt nunca atravessa a fronteira de persistência.
const SAFE=BigInt(Number.MAX_SAFE_INTEGER),MAX_DIGITS=120;
function parts(value){
 if(typeof value==='bigint')return [value,1n];
 if(typeof value!=='number'&&typeof value!=='string')throw Error('Valor monetário inválido.');
 const text=String(value).trim();if(text.length>MAX_DIGITS+30)throw Error('Valor monetário muito extenso.');
 const m=/^([+-]?)(\d+)(?:\.(\d*))?(?:e([+-]?\d+))?$/i.exec(text);if(!m)throw Error('Valor monetário inválido.');
 const exp=Number(m[4]||0)-(m[3]||'').length;if(!Number.isInteger(exp)||Math.abs(exp)>400)throw Error('Valor monetário fora da escala.');
 let n=BigInt((m[1]==='-'?'-':'')+m[2]+(m[3]||'')),d=1n;if(exp>=0)n*=10n**BigInt(exp);else d=10n**BigInt(-exp);return [n,d];
}
function div(n,d,mode='round'){if(d<=0n)throw Error('Divisor inválido.');const q=n/d,r=n%d;if(mode==='floor')return r<0n?q-1n:q;if(mode==='ceil')return r>0n?q+1n:q;return r>=0n?(r*2n>=d?q+1n:q):(-r*2n>d?q-1n:q);}
function integer(value){const [n,d]=parts(value);return div(n,d);}
function out(n){const a=n<0n?-n:n;if(a.toString().length>MAX_DIGITS)throw Error('Valor monetário fora da escala.');return a<=SAFE?Number(n):n.toString();}
const round=n=>out(integer(n)),add=(...values)=>out(values.reduce((n,v)=>n+integer(v),0n)),sub=(a,b)=>out(integer(a)-integer(b)),neg=a=>out(-integer(a)),cmp=(a,b)=>integer(a)<integer(b)?-1:integer(a)>integer(b)?1:0;
function mul(value,factor,mode='round'){const [n,d]=parts(factor);return out(div(integer(value)*n,d,mode));}
function quotient(value,denominator,mode='round'){return out(div(integer(value),integer(denominator),mode));}
function valid(v,negative=false){if(typeof v==='number')return Number.isFinite(v)&&Number.isInteger(v)&&Math.abs(v)<1e120&&(negative||v>=0);return typeof v==='string'&&v.length<=MAX_DIGITS+1&&(negative?/^-?(?:0|[1-9]\d*)$/:/^(?:0|[1-9]\d*)$/).test(v);}
function input(v){try{const n=round(v);return cmp(n,0)>=0?n:null;}catch(e){return null;}}
function format(v){return integer(v).toLocaleString('pt-BR');}
function percent(value,rate){const [n,d]=parts(rate);return out(div(integer(value)*n,d*100n));}
const min=(a,b)=>cmp(a,b)<0?a:b,max=(a,b)=>cmp(a,b)>0?a:b;
const M={parts,div,integer,out,round,add,sub,neg,cmp,mul,percent,quotient,valid,input,format,min,max,MAX_DIGITS};
if(typeof module!=='undefined'&&module.exports)module.exports=M;else root.LifeMoney=M;
})(typeof globalThis!=='undefined'?globalThis:this);
