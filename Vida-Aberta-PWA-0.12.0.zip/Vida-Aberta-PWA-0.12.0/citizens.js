(function(root){
'use strict';
// Economia e pesquisa fictícias. Competência e conhecimento não têm teto de nível.
const own=(o,k)=>Object.prototype.hasOwnProperty.call(o,k),clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n)),money=n=>Math.round(clamp(n,0,1e15));
const research={
 aprendizagem:{name:'Pesquisa de aprendizagem',icon:'🧩',desc:'Testa prática, revisão, memória e feedback para aprender mais em menos tempo. As descobertas aceleram a formação de toda a população atendida.'},
 videoaulas:{name:'Pesquisa de videoaulas',icon:'🎬',desc:'Desenvolve explicações, exercícios, avaliações e materiais reutilizáveis para aprender bem por vídeo. Melhora o ensino e permite atender com menos professores.'}
};
function initialize(g){
 const competence=Math.max(1,g.metrics.educacao),employment=Math.max(1,g.metrics.emprego),workforce=Math.max(1,Math.round(g.population*.6));
 g.citizens={competence,referenceCompetence:competence,referenceEmployment:employment,referenceGdp:g.gdp,referenceWage:g.gdp*.42/(workforce*employment/100)};
 g.research=Object.fromEntries(Object.keys(research).map(id=>[id,{annual:0,knowledge:0,totalSpent:0}]));
}
function power(g,id){const p=g.projects[id];return p&&p.level?Math.sqrt(p.level)*p.condition/100*p.operating:0;}
function education(g){
 const tracks=g.research,methods=tracks?tracks.aprendizagem.knowledge:0,video=tracks?tracks.videoaulas.knowledge:0;
 const videoQuality=1-Math.exp(-Math.log1p(video)*.4),offline=clamp(.35+power(g,'bibliotecas')*.12,0,.8),reach=offline+(1-offline)*g.metrics.conectividade/100;
 return {learningMultiplier:(1+Math.log1p(methods)*.3)*(1+videoQuality*reach*.5),videoQuality,videoReach:reach,teacherBoost:videoQuality*reach*2};
}
function snapshot(g){
 const expanded=g.statecraft&&g.statecraft.enabled?g.statecraft.economy:null;
 const c=g.citizens,workforce=Math.max(1,Math.round(g.population*.6)),employmentRate=g.metrics.emprego,unemploymentRate=100-employmentRate,employed=Math.round(workforce*employmentRate/100),unemployed=workforce-employed;
 const competenceFactor=c.competence/c.referenceCompetence,employmentFactor=employmentRate/c.referenceEmployment,laborIndex=Math.min(Number.MAX_VALUE,competenceFactor*employmentFactor),annualWage=expanded?expanded.annualWage:money(c.referenceWage*(g.gdp/c.referenceGdp)*competenceFactor);
 return {competence:c.competence,workforce,employmentRate,unemploymentRate,employed,unemployed,annualWage,monthlyWage:money(annualWage/12),wageBill:money(annualWage*workforce*employmentRate/100),laborIndex};
}
const laborShares={irpf:1,irpj:.8,cofins:.75,iss:.8,icms:.75,ipi:.8,importacao:.65,itbi:.45,iptu:.2,ipva:.35,itcmd:.3};
function taxFactor(snapshot,id){const share=own(laborShares,id)?laborShares[id]:0;return Math.min(Number.MAX_VALUE,1-share+share*snapshot.laborIndex);}
function planned(g){return Object.values(g.research).reduce((n,r)=>n+r.annual,0);}
function annual(g,paid,coverage){
 const items=[],quality=g.metrics.educacao/100,unit=Math.max(1,g.gdp*.00025);
 for(const id of Object.keys(research)){
  const r=g.research[id],amount=paid[id]||0,before=r.knowledge,gain=amount/unit*(.5+quality*.5);
  r.knowledge+=gain;r.totalSpent=money(r.totalSpent+amount);items.push({id,planned:r.annual,paid:amount,before,after:r.knowledge,gain});
 }
 const tools=education(g),educationCoverage=clamp(coverage,0,1.5),gain=2*quality*educationCoverage*tools.learningMultiplier;
 g.citizens.competence+=gain;
 return {research:{planned:planned(g),paid:items.reduce((n,r)=>n+r.paid,0),items},gain,educationCoverage,...tools};
}
function valid(g,num){
 const c=g.citizens;if(!c||!num(c.competence,0,Number.MAX_VALUE)||!num(c.referenceCompetence,1,100)||!num(c.referenceEmployment,1,100)||!num(c.referenceGdp,1e7,5e14)||!num(c.referenceWage,0,1e15)||!g.research||Array.isArray(g.research)||Object.keys(g.research).length!==Object.keys(research).length)return false;
 return Object.keys(research).every(id=>{const r=g.research[id];return r&&num(r.annual,0,1e15)&&num(r.knowledge,0,Number.MAX_VALUE)&&num(r.totalSpent,0,1e15);});
}
function validSnapshot(x,num){return !!x&&['competence','annualWage','monthlyWage','wageBill','laborIndex'].every(k=>num(x[k],0,Number.MAX_VALUE))&&['employmentRate','unemploymentRate'].every(k=>num(x[k],0,100))&&['workforce','employed','unemployed'].every(k=>Number.isInteger(x[k])&&num(x[k],0,5e8))&&Math.abs(x.employmentRate+x.unemploymentRate-100)<1e-8&&x.employed+x.unemployed===x.workforce;}
function validReport(r,num){
 if(r.researchPaid!==undefined&&!num(r.researchPaid,0,2e15))return false;
 if(!r.citizens)return r.researchPaid===undefined;const c=r.citizens;
 if(!validSnapshot(c.before,num)||!validSnapshot(c.after,num)||!num(c.gain,0,Number.MAX_VALUE)||!num(c.educationCoverage,0,1.5)||!num(c.learningMultiplier,1,Number.MAX_VALUE)||!num(c.videoQuality,0,1)||!num(c.videoReach,0,1)||!num(c.teacherBoost,0,2)||!c.research)return false;
 const q=c.research;if(!num(q.planned,0,2e15)||!num(q.paid,0,2e15)||q.paid!==r.researchPaid||!Array.isArray(q.items)||q.items.length!==2||q.items.some(x=>!x)||new Set(q.items.map(x=>x.id)).size!==2)return false;
 return Math.abs(c.after.competence-c.before.competence-c.gain)<=Math.max(1,c.after.competence)*1e-10&&q.paid===q.items.reduce((n,x)=>n+x.paid,0)&&q.items.every(x=>x&&own(research,x.id)&&['planned','paid','before','after','gain'].every(k=>num(x[k],0,Number.MAX_VALUE))&&x.paid<=x.planned&&x.after>=x.before&&Math.abs(x.after-x.before-x.gain)<=Math.max(1,x.after)*1e-10);
}
const C={research,initialize,education,snapshot,taxFactor,planned,annual,valid,validSnapshot,validReport};
if(typeof module!=='undefined'&&module.exports)module.exports=C;else root.LifeCitizens=C;
})(typeof globalThis!=='undefined'?globalThis:this);
