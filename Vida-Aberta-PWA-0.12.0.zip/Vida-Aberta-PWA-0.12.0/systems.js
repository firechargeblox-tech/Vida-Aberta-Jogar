(function(root){
'use strict';
const M=typeof module!=='undefined'&&module.exports?require('./money.js'):root.LifeMoney;
const D=typeof module!=='undefined'&&module.exports?require('./data.js'):root.LifeData;
const W=typeof module!=='undefined'&&module.exports?require('./world.js'):root.LifeWorld;
const own=(o,k)=>Object.prototype.hasOwnProperty.call(o,k);
const emptySupport=()=>Object.fromEntries(Object.keys(D.supportTypes).map(k=>[k,0]));
const CHAMPION_POINTS=[60,130,280,600];
function specialtyFor(p){const keys=p.age<18?['estudos','esporte','criacao']:Object.keys(D.friendRoles);let hash=0;for(const c of String(p.name)+'/'+p.id)hash=(hash*31+c.charCodeAt(0))>>>0;return keys[hash%keys.length];}
function favorQuote(s,id){const p=s.people.find(x=>x.id===id);if(!p||!p.alive||p.kind!=='friend'||p.bond<100||p.lastFavorYear===s.year)return null;const role=D.friendRoles[p.specialty];if(!role)return null;return {id:p.id,name:p.name,specialty:p.specialty,benefit:role.benefit,description:role.description,hours:6};}
function favorList(s){return s.people.filter(p=>p.alive&&p.kind==='friend'&&p.bond>=100&&p.lastFavorYear!==s.year).map(p=>{const role=D.friendRoles[p.specialty];return {id:p.id,name:p.name,specialty:p.specialty,benefit:role.benefit,description:role.description,hours:6};});}
function allFavorsQuote(s){const items=favorList(s);return {items,count:items.length,hours:items.reduce((n,x)=>n+x.hours,0),cost:0};}
function chosenVehicle(s,category='city'){
 if(!s||s.prison||s.transport==='none')return null;
 const owned=s.assets.filter(a=>own(D.vehicles,a.type));
 let a;if(s.transport&&s.transport!=='auto')a=owned.find(x=>x.id===s.transport);else a=owned.reduce((best,x)=>!best||D.vehicles[x.type][category]>D.vehicles[best.type][category]?x:best,null);
 if(!a)return null;const data=D.assets.find(x=>x.id===a.type);return {id:a.id,type:a.type,name:data.name,icon:data.icon,rate:D.vehicles[a.type][category]||0};
}
function rawHours(s,type,p={}){
 const F=typeof module!=='undefined'&&module.exports?require('./freedom.js'):root.LifeFreedom;if(F&&F.actions.includes(type))return F.hours(s,type,p);
 const office=s.politics&&s.politics.office,g=office&&s.governments[office.id];if(g&&g.statecraft&&g.statecraft.enabled&&(/^(setPublic|setPersonalPublic|fundPublic|setTax|setJustice|setProject|saveCivic|setCivic|fundCivic|reformInstitutions|setOrganization|public|toggleLaw|donatePublic|optimizePublic|repayPublic|createOrganization)/.test(type)||type==='govern'))return 0;
 if(type==='payReparation')return 2;if(type==='reviewReparation')return 12;if(type==='reportInGoodFaith')return 4;
 if(['setPersonalPublicFunding','fundPublicExpense','repayPublicPersonally'].includes(type))return 8;
 if(type==='saveCivicProgram')return 24;
 if(['reformInstitutions','setJusticeRules'].includes(type))return 48;
 if(type==='createOrganization')return 24;
 if(['setCivicProgram','fundCivicProgram','setTaxRules','setPublicAutomation','setOrganization','publicReserveMove'].includes(type))return 8;
 if(['setPublicStaff','optimizePublicStaff'].includes(type))return 8;
 if(['setPublicResearch','setProjectOperating','fundPublicProjectPersonally'].includes(type))return 4;
 if(['setTax','setPublicBudget','publicFinance','publicLoan','publicRepay','donatePublic'].includes(type))return type==='setTax'?8:4;
 if(type==='toggleLaw')return 24;
 if(type==='fundPublicProject')return 16;
 if(type==='meet')return own(W.circles,p.circle||'bairro')?W.circles[p.circle||'bairro'].hours:0;
 if(type==='startCampaign')return 120;
 if(type==='campaignAction')return p.id==='comicio'?48:24;
 if(type==='holdElection')return 24;
 if(type==='govern')return 80;
 if(type==='resignOffice')return 4;
 if(type==='cancelCampaign')return 2;
 if(type==='tradeCrypto')return 1;
 if(type==='train')return own(D.time.train,p.intensity)?D.time.train[p.intensity]:D.time.train.normal;
 if(type==='activity')return own(D.time.activity,p.id)?D.time.activity[p.id]:0;
 if(type==='project')return own(D.time.project,p.id)?D.time.project[p.id]:0;
 if(type==='adventure')return own(D.time.adventure,p.id)?D.time.adventure[p.id]:0;
 if(type==='interact')return own(D.time.interact,p.action)?D.time.interact[p.action].hours:0;
 if(type==='study'&&s.school.status==='incompleto')return D.time.fixed.equivalencia;
 if(type==='risk')return p.id==='contrabando'?72:12;
 if(type==='choose'){const durations=D.time.event[s.pending]||[6,3,1];return durations[Number(p.index)]||1;}
 if(type==='enterTournament')return D.tiers[p.tier]?D.tiers[p.tier].entryHours:0;
 if(type==='round'&&s.tournament){const t=D.tiers[s.tournament.tier];return t.roundHours+(s.tournament.round>0?t.gapHours:0);}
 if(type==='claimFavor')return 6;
 if(type==='claimAllFavors')return allFavorsQuote(s).hours;
 if(type==='applyJob'&&s.support&&s.support.referral>0)return D.time.fixed.applyJob-4;
 return own(D.time.fixed,type)?D.time.fixed[type]:0;
}
function timeQuote(s,type,p={}){
 if(type==='interactAll')return groupQuote(s,p.action)||{hours:0,base:0,activity:0,travel:0,travelBase:0,wait:0,saved:0};
 if(type==='autoSweep')return sweepQuote(s,p.id);
 const base=rawHours(s,type,p);let travelBase=0,wait=0,category='city';
 if(type==='startCampaign')travelBase=12;
 else if(type==='campaignAction')travelBase=p.id==='comicio'?8:2;
 else if(type==='govern')travelBase=8;
 else if(type==='meet')travelBase=p.circle==='celebridades'?12:p.circle==='cinema'?6:2;
 else if(type==='train'&&['luta','futebol','corrida','musica','cozinha'].includes(p.id))travelBase={leve:1,normal:4,intenso:8}[p.intensity]||4;
 else if(type==='activity')travelBase=D.travel.activity[p.id]||0;
 else if(type==='project')travelBase=D.travel.project[p.id]||0;
 else if(type==='adventure'){travelBase=D.travel.adventure[p.id]||0;if(['viagem','desafio'].includes(p.id))category='trip';}
 else if(type==='interact'&&p.action==='passear'){travelBase=6;const person=s.people.find(x=>x.id===p.id);category=person&&['parent','child','partner','spouse','sibling'].includes(person.kind)?'family':'city';}
 else if(type==='enterTournament'){travelBase=[2,3,4,6][p.tier]||0;category=Number(p.tier)>1?'trip':'city';}
 else if(type==='round'&&s.tournament){const t=D.tiers[s.tournament.tier];wait=s.tournament.round>0?t.gapHours:0;}
 else if(type==='choose'){const list=D.travel.event[s.pending];travelBase=list?list[Number(p.index)]||0:0;if(s.pending==='travel')category='trip';}
 else if(type==='risk')travelBase=p.id==='contrabando'?12:2;
 else travelBase=D.travel.fixed[type]||0;
 if(['move'].includes(type))category='trip';if(['marry','child'].includes(type))category='family';
 travelBase=Math.min(travelBase,Math.max(0,base-wait));
 const vehicle=chosenVehicle(s,category),travel=vehicle?Math.ceil(travelBase*(1-vehicle.rate)):travelBase,activity=Math.max(0,base-travelBase-wait),saved=travelBase-travel;
 return {hours:activity+travel+wait,base,activity,travelBase,travel,wait,saved,category,vehicleId:vehicle?vehicle.id:null,vehicleName:vehicle?vehicle.name:null};
}
function groupQuote(s,action){
 if(!own(D.time.interact,action))return null;const d=D.time.interact[action],people=s.people.filter(p=>p.alive&&p.bond<100),cost=action==='passear'&&s.age<16?0:d.cost;
 const sum={action,count:people.length,ids:people.map(p=>p.id),hours:0,base:0,activity:0,travelBase:0,travel:0,wait:0,saved:0,cost:cost*people.length,inPrison:action==='conversar'};
 for(const person of people){const q=timeQuote(s,'interact',{id:person.id,action});for(const k of ['hours','base','activity','travelBase','travel','wait','saved'])sum[k]+=q[k];}return sum;
}
function tournamentDuration(tierIndex,s){const t=D.tiers[tierIndex];if(!t)return 0;return (s?timeQuote(s,'enterTournament',{tier:tierIndex}).hours:t.entryHours)+t.roundHours*t.rounds+t.gapHours*(t.rounds-1);}
function sweepQuote(s,id){
 const unlocked=Array.isArray(s.mastered)&&s.mastered.includes(id),items=[];
 if(unlocked)D.tiers.forEach((t,tier)=>{if(!s.tournamentYear[id+':'+tier]){const entry=timeQuote(s,'enterTournament',{id,tier});items.push({tier,name:t.name,fee:t.fee,prize:t.prize,points:CHAMPION_POINTS[tier],hours:tournamentDuration(tier,s),saved:entry.saved,wait:t.gapHours*(t.rounds-1),rounds:t.rounds});}});
 return {id,unlocked,items,count:items.length,hours:items.reduce((n,x)=>n+x.hours,0),base:items.reduce((n,x)=>n+x.hours+x.saved,0),saved:items.reduce((n,x)=>n+x.saved,0),wait:items.reduce((n,x)=>n+x.wait,0),cost:items.reduce((n,x)=>n+x.fee,0),prize:items.reduce((n,x)=>n+x.prize,0),points:items.reduce((n,x)=>n+x.points,0)};
}
function snapshot(s){return {cash:s.cash,debt:s.debt,hoursLeft:s.hoursLeft,reputation:s.reputation,fame:s.fame,grades:s.school.grades,performance:s.performance,prison:s.prison,record:s.record,job:s.job,stats:{...s.stats},skills:{...s.skills},people:s.people.map(p=>({id:p.id,name:p.name,bond:p.bond}))};}
function changes(s,before){
 const result=[];function add(label,a,b,type='points',positiveGood=true){const delta=type==='money'?M.sub(b,a):Math.round((b-a)*100)/100;if(delta)result.push({label,delta,type,good:type==='hours'?null:positiveGood?delta>0:delta<0});}
 add('Dinheiro',before.cash,s.cash,'money');add('Dívida',before.debt,s.debt,'money',false);add('Horas',before.hoursLeft,s.hoursLeft,'hours');add('Reputação',before.reputation,s.reputation);add('Fama',before.fame,s.fame);add('Notas',before.grades,s.school.grades);add('Desempenho',before.performance,s.performance);add('Pena de prisão',before.prison,s.prison,'years',false);add('Registros de infração',before.record,s.record,'points',false);
 for(const [k,d] of Object.entries(D.stats))add(d.name,before.stats[k],s.stats[k]);for(const [k,d] of Object.entries(D.skills))add(d.name,before.skills[k],s.skills[k]);
 const oldPeople=new Map(before.people.map(p=>[p.id,p]));for(const p of s.people){const old=oldPeople.get(p.id);if(old)add('Vínculo · '+p.name,old.bond,p.bond);else result.push({label:'Nova amizade · '+p.name,delta:0,type:'text',good:true});}
 if(before.job&&!s.job)result.push({label:'Seu emprego foi encerrado.',delta:0,type:'text',good:false});if(result.length>120){const core=result.filter(c=>!c.label.startsWith('Vínculo · ')),bonds=result.filter(c=>c.label.startsWith('Vínculo · ')),keep=Math.max(0,119-core.length),rest=bonds.slice(keep);return core.concat(bonds.slice(0,keep),{label:'Outros vínculos ('+rest.length+' pessoas)',delta:Math.round(rest.reduce((n,c)=>n+c.delta,0)*100)/100,type:'points',good:rest.every(c=>c.good===true)?true:rest.every(c=>c.good===false)?false:null});}return result;
}
const Systems={emptySupport,specialtyFor,favorQuote,favorList,allFavorsQuote,chosenVehicle,timeQuote,groupQuote,tournamentDuration,sweepQuote,snapshot,changes,CHAMPION_POINTS};
if(typeof module!=='undefined'&&module.exports)module.exports=Systems;else root.LifeSystems=Systems;
})(typeof globalThis!=='undefined'?globalThis:this);
