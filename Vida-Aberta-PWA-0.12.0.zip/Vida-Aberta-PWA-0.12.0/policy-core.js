(function(root){
'use strict';
const M=typeof module!=='undefined'&&module.exports?require('./money.js'):root.LifeMoney;
const own=(o,k)=>Object.prototype.hasOwnProperty.call(o,k),clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const clone=o=>JSON.parse(JSON.stringify(o)),sum=xs=>M.add(...xs),positive=v=>M.input(v)!==null&&M.cmp(v,0)>0;
function hash(t){let h=2166136261;for(const c of String(t)){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}h^=h>>>16;h=Math.imul(h,0x85ebca6b);return (h>>>0)/4294967296;}
function ratio(a,b,fallback=0){const n=Number(a),d=Number(b);return d>0&&Number.isFinite(n/d)?n/d:fallback;}
function number(v){return Number(M.round(v));}
function quantity(v){try{const [n,d]=M.parts(v);if(n<0n)return null;return M.out(M.div(n*100000000n,d,'floor'));}catch(e){return null;}}
function units(q){const n=M.integer(q),whole=n/100000000n,decimal=(n%100000000n).toString().padStart(8,'0').replace(/0+$/,'');return whole.toString()+(decimal?'.'+decimal:'');}
function value(q,price,mode='round'){const [n,d]=M.parts(price);return M.out(M.div(M.integer(q)*n,100000000n*d,mode));}
function affordable(cash,price){const [n,d]=M.parts(price);return M.out(M.integer(cash)*100000000n*d/n);}
function percentOf(v,rate){return M.percent(v,rate);}
function take(cash,requested){return M.min(M.max(0,cash),M.max(0,requested));}
function allocate(lines,available){const total=sum(lines.map(x=>x.amount)),budget=take(available,total),out={};if(M.cmp(total,0)<=0)return {total:0,byKey:out,ratio:1};const t=M.integer(total),b=M.integer(budget);let left=b;const fractions=[];for(const [i,l]of lines.entries()){const n=M.integer(l.amount),paid=n*b/t;out[l.key]=M.out(paid);left-=paid;fractions.push({key:l.key,r:n*b%t,i});}fractions.sort((a,b)=>a.r===b.r?a.i-b.i:a.r>b.r?-1:1);for(const x of fractions){if(left<=0n)break;out[x.key]=M.add(out[x.key],1);left--;}return {total:budget,byKey:out,ratio:ratio(budget,total,1)};}
function num(v,a=0,b=Number.MAX_VALUE){return typeof v==='number'&&Number.isFinite(v)&&v>=a&&v<=b;}
function text(v,max=120){return typeof v==='string'&&v.length>0&&v.length<=max;}
function moneyFields(o,keys,negative=false){return !!o&&keys.every(k=>M.valid(o[k],negative));}
function assert(condition,message){if(!condition)throw Error(message);}
function parseAmount(raw){const t=String(raw).trim().toLowerCase().replace(/r\$\s*/g,'').replace(/\s+/g,' '),match=t.match(/^([\d.,]+)\s*(mil|milh[aã]o|milh[oõ]es|mi|bilh[aã]o|bilh[oõ]es|bi|trilh[aã]o|trilh[oõ]es|tri|quadrilh[aã]o|quadrilh[oõ]es)?$/);if(!match)return null;let n=match[1];if(n.includes(',')&&n.includes('.'))n=n.replace(/\./g,'').replace(',','.');else if(n.includes(','))n=n.replace(',','.');else if(/^\d{1,3}(\.\d{3})+$/.test(n))n=n.replace(/\./g,'');const multipliers={mil:1000,'milhão':1e6,milhao:1e6,'milhões':1e6,milhoes:1e6,mi:1e6,'bilhão':1e9,bilhao:1e9,'bilhões':1e9,bilhoes:1e9,bi:1e9,'trilhão':1e12,trilhao:1e12,'trilhões':1e12,trilhoes:1e12,tri:1e12,'quadrilhão':1e15,quadrilhao:1e15,'quadrilhões':1e15,quadrilhoes:1e15};try{return M.mul(n,multipliers[match[2]]||1);}catch(e){return null;}}
const C={M,own,clamp,clone,sum,positive,hash,ratio,number,quantity,units,value,affordable,percentOf,take,allocate,num,text,moneyFields,assert,parseAmount};if(typeof module!=='undefined'&&module.exports)module.exports=C;else root.LifePolicyCore=C;
})(typeof globalThis!=='undefined'?globalThis:this);
