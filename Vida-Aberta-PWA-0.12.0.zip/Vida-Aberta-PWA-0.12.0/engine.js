(function(root){
'use strict';
const M=typeof module!=='undefined'&&module.exports?require('./money.js'):root.LifeMoney;
const D=typeof module!=='undefined'&&module.exports?require('./data.js'):root.LifeData;
const BASE_EVENTS=typeof module!=='undefined'&&module.exports?require('./events.js'):root.LifeEvents;
const Stories=typeof module!=='undefined'&&module.exports?require('./stories.js'):root.LifeStories;
const Systems=typeof module!=='undefined'&&module.exports?require('./systems.js'):root.LifeSystems;
const World=typeof module!=='undefined'&&module.exports?require('./world.js'):root.LifeWorld;
const Government=typeof module!=='undefined'&&module.exports?require('./government.js'):root.LifeGovernment;
const Justice=Government.Justice,Statecraft=Government.Statecraft,Timelines=typeof module!=='undefined'&&module.exports?require('./timelines.js'):root.LifeTimelines;
const Freedom=typeof module!=='undefined'&&module.exports?require('./freedom.js'):root.LifeFreedom;
const EVENTS=BASE_EVENTS.concat(Stories.followups);
const clamp=(n,a=0,b=100)=>Math.max(a,Math.min(b,Number(n)||0));
const money=M.round;
const find=(items,id)=>items.find(x=>x.id===id);
const own=(o,k)=>Object.prototype.hasOwnProperty.call(o,k);
function rand(s){let a=s.seed|0;a^=a<<13;a^=a>>>17;a^=a<<5;s.seed=a>>>0||1;return s.seed/4294967296;}
function integer(s,a,b){return Math.floor(a+rand(s)*(b-a+1));}
function pick(s,list){return list[Math.floor(rand(s)*list.length)];}
function uid(s){s.seq++;return 'p'+s.seq;}
function log(s,text,icon='•',category='vida'){s.history.unshift({age:s.age,text:String(text).slice(0,500),icon,category});s.history=s.history.slice(0,350);}
function person(s,kind,age){const p={id:uid(s),name:pick(s,D.names)+' '+pick(s,D.surnames),kind,age:Math.max(0,age),bond:kind==='parent'?80:integer(s,45,70),alive:true,lastContactYear:s.year,lastFavorYear:-1};p.specialty=Systems.specialtyFor(p);Object.assign(p,World.socialDefaults(p));return p;}
function canAddFriend(s){return s.people.length<D.MAX_PEOPLE&&s.people.filter(p=>p.kind==='friend').length<D.MAX_FRIENDS;}
function contact(s,p){p.lastContactYear=s.year;}
function interaction(s,action){if(!own(D.time.interact,action))return null;const d=D.time.interact[action];return {...d,cost:action==='passear'&&s.age<16?0:d.cost};}
function groupQuote(s,action){return Systems.groupQuote(s,action);}
function applyInteraction(s,p,d){const gain=d.bond>0?d.bond+(s.trait==='sociavel'?4:0)+Math.floor(s.skills.diplomacia/25)+Math.max(0,Math.floor((s.stats.charisma-50)/25)):d.bond;p.bond=clamp(p.bond+gain);contact(s,p);s.stats.happiness=clamp(s.stats.happiness+(gain>0?4:-5));}
function tournamentDuration(tierIndex,state){return Systems.tournamentDuration(tierIndex,state);}
function actionHours(s,type,p={}){return Systems.timeQuote(s,type,p).hours;}
function create(config={}){
 const age=[0,6,16,18].includes(Number(config.age))?Number(config.age):16;
 const s={game:'vida-aberta',version:12,build:D.VERSION,seed:(Number(config.seed)||Date.now())>>>0||1,seq:0,
 name:String(config.name||'Fire').trim().slice(0,36)||'Fire',pronoun:['ele','ela','elu'].includes(config.pronoun)?config.pronoun:'elu',age,year:2026,origin:own(D.origins,config.origin)?config.origin:'comum',trait:own(D.traits,config.trait)?config.trait:'curioso',city:'litoral',sandbox:!!config.sandbox,
 freedom:Freedom.empty(),alive:true,cash:0,debt:0,stats:{health:90,happiness:78,smarts:50,charisma:50,fitness:55},skills:Object.fromEntries(Object.keys(D.skills).map(k=>[k,age>=16&&!Freedom.extraSkills.includes(k)?8:0])),hoursLeft:D.YEAR_HOURS,school:{status:age<6?'infancia':age<18?'cursando':'concluido',grades:70},college:null,degrees:[],job:null,jobLevel:1,performance:55,jobYears:0,retired:false,pension:0,workload:'equilibrado',
 reputation:50,fame:0,record:0,prison:0,people:[],governments:{},workSchedule:{days:5,hours:8},politicalWorld:Statecraft.createWorld((Number(config.seed)||1)>>>0||1),timelines:Timelines.empty(),publicFunding:{},accountability:Justice.emptyPersonal(),civicLife:Government.Civic.emptyLife(),politics:World.emptyPolitics(),market:null,support:Systems.emptySupport(),mastered:[],transport:'auto',stories:[],followups:[],businesses:[],assets:[],investments:{reserva:0,acoes:0,cripto:0},lifestyle:'economico',tournament:null,rankings:Object.fromEntries(D.tournaments.map(t=>[t.id,0])),medals:[],tournamentYear:{},achievements:[],pending:null,eventMemory:[],yearFlags:{},history:[],reports:[],lastResult:null,generation:1,ancestors:[]};
 s.market=World.emptyMarket(s.seed);
 for(const k of Object.keys(s.stats))s.stats[k]=clamp(s.stats[k]+integer(s,-8,8));
 const boost=D.traits[s.trait].stat;s.stats[boost]=clamp(s.stats[boost]+10);
 s.cash=D.origins[s.origin].money;
 s.people.push(person(s,'parent',age+integer(s,23,32)),person(s,'parent',age+integer(s,23,35)));
 if(age>=6)s.people.push(person(s,'friend',age));
 log(s,age===0?'Sua história começou. Existe uma vida inteira para descobrir.':'Um novo capítulo começa. Você tem '+age+' anos e pode escolher seu caminho.','🌱');
 return s;
}
const partner=s=>s.people.find(p=>p.alive&&['partner','spouse'].includes(p.kind));
const children=s=>s.people.filter(p=>p.alive&&p.kind==='child');
function worth(s){return M.add(s.cash,M.neg(s.debt),M.neg(Justice.personalRemaining(s)),Freedom.value(s),...s.businesses.map(b=>money(find(D.businesses,b.type).cost*b.level*.7)),...s.assets.map(x=>x.value),...Object.values(s.investments),World.cryptoWorth(s));}
function salary(s){if(s.politics.office&&!s.prison)return find(World.offices,s.politics.office.id).pay;const j=find(D.jobs,s.job);const national=s.governments.presidente,x=national&&national.statecraft&&national.statecraft.enabled?national.statecraft:null,schedule=x?(x.labor.flexible?s.workSchedule:x.labor):null,hours=schedule?schedule.days*schedule.hours:40;return j&&!s.retired&&!s.prison?money(j.pay*hours/40*(1+(s.jobLevel-1)*.32)*find(D.cities,s.city).opportunity*(s.workload==='intenso'?1.2:s.workload==='leve'?.75:1)):0;}
function living(s){if(s.age<18)return 0;if(s.prison)return 1200+children(s).filter(p=>p.age<18).length*3000;const home=s.assets.some(x=>find(D.assets,x.type).type==='home')||s.freedom.properties.some(x=>x.type==='casa'&&!x.closed&&x.condition>=20);return money((find(D.lifestyles,s.lifestyle).cost*(home?.7:1)+children(s).filter(p=>p.age<18).length*4200)*find(D.cities,s.city).cost);}
function award(s,id){if(!s.achievements.includes(id)){s.achievements.push(id);const a=find(D.achievements,id);if(a)log(s,'Conquista: '+a.name,a.icon,'conquista');}}
function spend(s,hours,cost=0,minAge=0,inPrison=false){
 if(!s.alive)return 'Esta vida terminou. Continue por um descendente ou comece outra.';
 if(s.age<minAge)return 'Disponível a partir dos '+minAge+' anos.';
 if(s.prison&&!inPrison)return 'Essa ação fica indisponível durante a prisão.';
 if(s.hoursLeft<hours)return 'Tempo insuficiente: esta ação precisa de '+hours.toLocaleString('pt-BR')+' h, e restam '+s.hoursLeft.toLocaleString('pt-BR')+' h neste ano.';
 if(M.cmp(s.cash,cost)<0)return 'Dinheiro insuficiente. Você precisa de R$ '+Math.ceil(cost).toLocaleString('pt-BR')+'.';
 s.hoursLeft-=hours;s.cash=M.sub(s.cash,cost);return null;
}
function addSkill(s,key,n){if(!D.skills[key])return;s.skills[key]=clamp(s.skills[key]+n);if(s.skills[key]>=100)award(s,'master');}
function effect(s,e){
 for(const key of Object.keys(D.stats))if(e[key])s.stats[key]=clamp(s.stats[key]+e[key]);
 for(const key of ['reputation','fame'])if(e[key])s[key]=clamp(s[key]+e[key]);
 if(e.money){if(e.money<0&&M.cmp(s.cash,-e.money)<0){s.debt=M.sub(M.sub(s.debt,e.money),s.cash);s.cash=0;}else s.cash=M.add(s.cash,e.money);}
 if(e.skill)addSkill(s,e.skill,e.gain||3);
 if(e.friend&&canAddFriend(s))s.people.push(person(s,'friend',Math.max(6,s.age+integer(s,-3,3))));
 if(e.bond&&partner(s)){const p=partner(s);p.bond=clamp(p.bond+e.bond);contact(s,p);}
 if(e.childrenBond)children(s).forEach(p=>{p.bond=clamp(p.bond+e.childrenBond);contact(s,p);});
 if(e.grades)s.school.grades=clamp(s.school.grades+e.grades);
 if(e.performance)s.performance=clamp(s.performance+e.performance);
 if(e.prison){s.politics.office=null;s.politics.campaign=null;s.prison+=e.prison;s.job=null;s.retired=false;}
 if(e.record)s.record+=e.record;
 if(e.risk){const fail=rand(s)<e.risk;effect(s,fail?e.fail||{}:e.success||{});return fail?'fail':'success';}
 return '';
}
function eventEligible(s,e,allowFollowup=false){
 if(e.followup&&!allowFollowup)return false;
 if(s.age<e.min||s.age>e.max)return false;
 if(s.prison)return e.condition==='prison';
 if(e.condition==='prison')return false;
 if(e.condition==='job'&&!s.job)return false;
 if(e.condition==='business'&&!s.businesses.length)return false;
 if(e.condition==='partner'&&!partner(s))return false;
 if(e.condition==='child'&&!children(s).length)return false;
 if(e.condition==='fame'&&s.fame<15)return false;
 return true;
}
function newEvent(s){
 const due=s.followups.findIndex(q=>q.dueYear<=s.year&&eventEligible(s,EVENTS.find(e=>e.id===q.id),true));
 if(due>=0){const q=s.followups.splice(due,1)[0];s.pending=q.id;s.eventMemory.push(q.id);s.eventMemory=s.eventMemory.slice(-20);return EVENTS.find(e=>e.id===q.id);}
 const options=EVENTS.filter(e=>eventEligible(s,e)&&!s.eventMemory.slice(-9).includes(e.id));
 const pool=options.length?options:EVENTS.filter(e=>eventEligible(s,e));
 const e=pick(s,pool);if(!e)return null;
 s.pending=e.id;s.eventMemory.push(e.id);s.eventMemory=s.eventMemory.slice(-20);return e;
}
function finishYear(s){
 const from=s.age;let taxableIncome=0;const imprisoned=s.prison>0;let lines=[];let income=0,expenses=0;
 if(s.age<18){const support=D.origins[s.origin].support;s.cash=M.add(s.cash,support);income=M.add(income,support);lines.push({label:'Mesada e apoio familiar',amount:support});}
 if(imprisoned){s.politics.office=null;s.politics.campaign=null;}
 const office=s.politics.office,politicalPay=office?salary(s):0;
 if(politicalPay){s.cash=M.add(s.cash,politicalPay);income=M.add(income,politicalPay);taxableIncome=M.add(taxableIncome,politicalPay);lines.push({label:'Remuneração · '+find(World.offices,office.id).name,amount:politicalPay});}
 const pay=office?0:salary(s);if(pay){s.cash=M.add(s.cash,pay);income=M.add(income,pay);taxableIncome=M.add(taxableIncome,pay);lines.push({label:'Salários do ano',amount:pay});s.jobYears++;s.performance=clamp(s.performance+3+(s.workload==='intenso'?6:0)+Math.floor(s.skills.lideranca/25)+Math.floor(s.stats[D.stats[D.skills[find(D.jobs,s.job).skill].stat]?D.skills[find(D.jobs,s.job).skill].stat:'smarts']/40));const j=find(D.jobs,s.job);addSkill(s,j.skill,2);if(s.performance>=82){s.jobLevel++;s.performance=55;log(s,'Seu trabalho rendeu uma promoção em '+j.name+'.','📈','carreira');}s.stats.health=clamp(s.stats.health-(s.workload==='intenso'?7:s.workload==='leve'?0:2));s.stats.happiness=clamp(s.stats.happiness+(s.workload==='leve'?4:s.workload==='intenso'?-6:0));}
 if(s.retired){s.cash=M.add(s.cash,s.pension);income=M.add(income,s.pension);taxableIncome=M.add(taxableIncome,s.pension);lines.push({label:'Renda da aposentadoria',amount:s.pension});}
 for(const b of s.businesses){const d=find(D.businesses,b.type);const demand=.78+rand(s)*.5;const skill=(s.skills[d.skill]+s.skills.negocios)/200;const strategy=b.strategy==='qualidade'?1.1:b.strategy==='escala'?1.3:1;let rev=money(d.revenue*Math.pow(b.level,.92)*demand*(.8+skill*.5)*strategy*(1+s.skills.lideranca/1000)*(imprisoned?.7:1)*find(D.cities,s.city).opportunity*Government.economicFactor(s));const cost=money(d.expense*Math.pow(b.level,.92)*(b.strategy==='qualidade'?1.08:b.strategy==='escala'?1.27:1)*(1-s.skills.financas/1000));const supported=s.support.supplier>0;if(supported){s.support.supplier--;rev=money(rev*1.1);}const taxes=Government.businessTax(s,d,rev,cost,b),taxTotal=money(taxes.total),net=money(rev-cost-taxTotal);s.cash=M.add(s.cash,net);income=M.add(income,rev);expenses=M.add(expenses,cost+taxTotal);b.last=net;if(taxTotal)lines.push({label:'Tributos da empresa · '+d.name,amount:-taxTotal});lines.push({label:d.name+' · nível '+b.level+(supported?' · fornecedor indicado':'')+(taxTotal?' · antes dos tributos':''),amount:money(rev-cost)});}
 for(const a of s.assets){const d=find(D.assets,a.type);const change=d.type==='vehicle'?-.08: -.03+rand(s)*.12;a.value=money(a.value*(1+change));if(d.rent){const rent=money(d.rent*find(D.cities,s.city).cost);s.cash=M.add(s.cash,rent);income=M.add(income,rent);lines.push({label:'Aluguel · '+d.name,amount:rent});}const supported=d.type==='vehicle'&&s.support.maintenance>0;const maintenance=World.maintenance(s,d,supported),upkeep=maintenance.cost;if(supported)s.support.maintenance--;s.cash=M.sub(s.cash,upkeep);expenses=M.add(expenses,upkeep);lines.push({label:'Manutenção · '+d.name+(maintenance.rate?' · mecânica −'+Math.round(maintenance.rate*100)+'%':'')+(supported?' · apoio −50%':''),amount:-upkeep});if(d.joy)s.stats.happiness=clamp(s.stats.happiness+d.joy*.25);}
 for(const d of D.investments){if(d.id==='cripto')continue;const current=s.investments[d.id];if(current>0){const delta=M.mul(current,d.low+rand(s)*(d.high-d.low));s.investments[d.id]=M.max(0,M.add(current,delta));lines.push({label:'Variação · '+d.name,amount:delta});}}
 const freedomYear=Freedom.annual(s,Government,rand,log);income=M.add(income,freedomYear.income);expenses=M.add(expenses,freedomYear.expenses);taxableIncome=M.add(taxableIncome,freedomYear.taxable);lines.push(...freedomYear.lines);
 const incomeTax=Government.personalTax(s,taxableIncome),assetTax=money(s.assets.reduce((n,a)=>n+Government.assess(s,find(D.assets,a.type).type==='vehicle'?'ipva':'iptu',a.value),0));const personalTaxes=money(incomeTax+assetTax);if(personalTaxes){s.cash=M.sub(s.cash,personalTaxes);expenses=M.add(expenses,personalTaxes);lines.push({label:'Tributos pessoais de renda e patrimônio',amount:-personalTaxes});}
 const reparations=Justice.personalYear(s,M.max(0,M.sub(taxableIncome,incomeTax)),living(s));if(M.cmp(reparations,0)>0){expenses=M.add(expenses,reparations);lines.push({label:'Parcelas de reparação pagas às vítimas',amount:M.neg(reparations)});log(s,'Reparação: R$ '+M.format(reparations)+' pagos às vítimas neste ano. Saldo: R$ '+M.format(Justice.personalRemaining(s))+'.','⚖️','justica');}
 const civicSpent=Government.Civic.annualOrganizations(s,log);if(civicSpent){expenses=M.add(expenses,civicSpent);lines.push({label:'Aportes pessoais em organizações civis',amount:-civicSpent});}
 const publicReports=Object.values(s.governments).map(g=>({id:g.id,report:Government.annual(s,g)}));for(const x of publicReports){if(s.politics.office&&s.politics.office.id===x.id){log(s,'Governo: '+Math.round(x.report.coverage*100)+'% do plano anual executado. '+x.report.completed.length+' etapa(s) de projeto concluída(s). '+(x.report.coverage<.98?'Faltou caixa para parte dos planos.':'O relatório público está disponível.'),'🏛️','politica');for(const note of x.report.notes.slice(0,6))log(s,note,'🏗️','politica');}}
 const sponsored=M.add(...publicReports.map(x=>x.report.personalFunding.total));if(M.cmp(sponsored,0)>0){expenses=M.add(expenses,sponsored);lines.push({label:'Custeio pessoal de despesas públicas',amount:M.neg(sponsored)});}
 const cost=living(s);s.cash=M.sub(s.cash,cost);expenses=M.add(expenses,cost);if(cost)lines.push({label:'Custo de vida e dependentes',amount:-cost});
 if(s.college&&!imprisoned){const c=find(D.degrees,s.college.id);const fee=s.college.scholarship?0:c.cost;if(fee===0||s.cash>=fee){s.cash=M.sub(s.cash,fee);expenses=M.add(expenses,fee);lines.push({label:'Faculdade · '+c.name,amount:-fee});s.college.progress++;addSkill(s,c.skill,7);if(s.college.progress>=c.years){s.degrees.push(c.id);s.college=null;award(s,'degree');log(s,'Você concluiu '+c.name+'. Novas carreiras estão abertas.','🎓','carreira');}}else log(s,'A faculdade ficou pausada neste ano por falta de dinheiro para a mensalidade anual.','🎓','carreira');}
 if(s.debt>0){const interest=M.mul(s.debt,.12);s.debt=M.add(s.debt,interest);expenses=M.add(expenses,interest);lines.push({label:'Juros da dívida (12% ao ano)',amount:M.neg(interest)});}
 if(s.cash<0){const shortage=M.neg(s.cash);s.debt=M.add(s.debt,shortage);s.cash=0;s.stats.happiness=clamp(s.stats.happiness-8);lines.push({label:'Despesas sem cobertura viraram dívida',amount:shortage,transfer:true});log(s,'Faltaram R$ '+Math.round(shortage).toLocaleString('pt-BR')+' para fechar o ano. O valor entrou na dívida.','⚠️','dinheiro');}
 const hoursUsed=D.YEAR_HOURS-s.hoursLeft;
 s.cash=money(s.cash);s.debt=money(s.debt);s.age=s.sandbox?Math.min(120,s.age+1):s.age+1;s.year=Math.min(9999,s.year+1);s.hoursLeft=D.YEAR_HOURS;s.yearFlags={};s.tournamentYear={};s.support=Systems.emptySupport();
 const marketDelta=M.sub(World.cryptoWorth(s),World.cryptoWorth(s,from));if(marketDelta)lines.push({label:'Variação · criptomoedas fictícias',amount:marketDelta});
 if(from<30&&s.age>=30){const survivor=World.coins.find(c=>World.profile(s,c.id)===0);log(s,'O mercado de criptomoedas mudou: '+survivor.name+' tem cotação-base de R$ 1.000.000.000 por unidade.'+(World.price(s,survivor.id)===0?' Sua concentração anterior já derrubou essa moeda; ela continua sem valor.':'')+' As outras sete perderam todo o valor. Concentração acima de 50% também zera uma moeda.','🪙','dinheiro');}
 if(office){office.remaining--;s.politics.experience=Math.min(1000,s.politics.experience+1);if(!office.remaining){log(s,'Seu mandato de '+find(World.offices,office.id).name+' terminou. Você pode voltar às urnas.','🗳️','politica');s.politics.office=null;}}
 if(s.politics.campaign&&s.politics.campaign.year<s.year){s.politics.campaign=null;log(s,'A campanha anterior terminou sem votação. O orçamento já gasto não foi devolvido.','🗳️','politica');}
 for(const p of s.people){if(!p.alive)continue;p.age++;const inactive=s.year-p.lastContactYear;if(inactive>=3&&inactive%3===0){const before=p.bond;p.bond=clamp(p.bond-10);if(p.bond<before)log(s,'O vínculo com '+p.name+' diminuiu em 10 após '+inactive+' anos sem interação.','🍂','pessoas');}if(p.age>78&&rand(s)<(p.age-76)*.006){p.alive=false;log(s,p.name+' morreu aos '+p.age+' anos. As lembranças continuam com você.','🕯️','pessoas');if(p.kind==='parent'){const inheritance=money(D.origins[s.origin].money*(.8+rand(s)*2));s.cash=M.add(s.cash,inheritance);income=M.add(income,inheritance);if(inheritance)lines.push({label:'Herança familiar',amount:inheritance});}s.stats.happiness=clamp(s.stats.happiness-10);}if(p.alive)World.evolveFriend(s,p,rand,log);}
 if(s.age===6){s.school.status='cursando';log(s,'Seu primeiro ano de escola começou.','🎒','carreira');}
 if(s.school.status==='cursando'){s.school.grades=clamp(s.school.grades+integer(s,-7,4)+(s.trait==='curioso'?2:0));s.stats.smarts=clamp(s.stats.smarts+1);if(s.age>=18){s.school.status=s.school.grades>=45?'concluido':'incompleto';log(s,s.school.status==='concluido'?'Você concluiu o ensino médio.':'O ensino médio ficou incompleto. Você pode fazer a equivalência depois.','🎓','carreira');}}
 if(imprisoned){s.prison--;if(!s.prison)log(s,'Você recuperou a liberdade. É hora de escolher o próximo passo.','🔓');}
 const older=s.age>85?2.3:s.age>60?1.25:s.age>30?.5:0;
 s.stats.health=clamp(s.stats.health-older+integer(s,-2,2));s.stats.happiness=clamp(s.stats.happiness+find(D.lifestyles,s.lifestyle).joy-(s.age>17&&s.cash===0?3:0));
 if(s.age>=100)award(s,'century');if(worth(s)>=1000000)award(s,'million');
 const death=s.stats.health<=0||s.age>=120||(s.age>=75&&rand(s)<Math.max(0,(s.age-74)*.0025+(35-s.stats.health)*.001));
 if(death&&!s.sandbox){s.alive=false;s.pending=null;s.tournament=null;s.politics.office=null;s.politics.campaign=null;log(s,'Sua história terminou aos '+s.age+' anos. Você deixou marcas e caminhos para quem vem depois.','🕯️');}
 if(s.sandbox&&s.stats.health<5)s.stats.health=5;
 const report={age:from,year:s.year-1,income:money(income),expenses:money(expenses),balance:M.sub(income,expenses),hoursUsed,lines};s.reports.unshift(report);s.reports=s.reports.slice(0,8);
 log(s,'Você completou '+s.age+' anos. '+(s.alive?'Um novo capítulo está aberto.':'Sua trajetória agora faz parte da história.'),'🎂');
 if(s.alive){const supports=Systems.favorList(s).length;if(supports)log(s,'Há '+supports+' amigo(s) com vínculo 100 oferecendo apoio neste ano.','🤝','pessoas');newEvent(s);}return report;
}
function ok(msg,extra={}){return Object.assign({ok:true,msg},extra);}const fail=msg=>({ok:false,msg});
function act(s,type,p={}){
 if(!s||s.game!=='vida-aberta')return fail('Não há uma vida em andamento.');
 if(!s.alive&&!['legacy','sandbox',...Timelines.actions].includes(type))return fail('Esta vida terminou. Escolha como continuar.');
 if(s.pending&&!['choose','deferEvent','sandbox',...Timelines.actions].includes(type))return fail('Resolva a escolha aberta antes de continuar.');
 if(s.tournament&&!['round','forfeit','sandbox',...Timelines.actions].includes(type))return fail('Conclua ou abandone seu torneio antes de continuar.');
 let err;const pay=(c=0,m=0,pr=false)=>spend(s,actionHours(s,type,p),c,m,pr);let msg='';
 if(Justice.restricted(s)&&['startCampaign','holdElection','campaignAction','govern'].includes(type))return fail('Há reparação pendente. Quite suas obrigações para recuperar a autoridade de concorrer e administrar recursos públicos.');
 if(Justice.personalActions.includes(type)){const result=Justice.personalAct(s,type,p,()=>pay(0,18,true));if(result.ok)log(s,result.msg,'⚖️','justica');return result;}
 if(Freedom.actions.includes(type)){const result=Freedom.act(s,type,p,Government,rand);if(result.ok)log(s,result.msg,'🧭','caminhos');return result;}
 if(Timelines.actions.includes(type)){const result=Timelines.act(s,type,p,{D,validate});return result;}
 if(Statecraft.actionTypes.includes(type)){const gate=spend(s,0,0,18);if(gate)return fail(gate);if(Justice.restricted(s)&&!['statePersonalSchedule'].includes(type))return fail('Reparação pendente: quite suas obrigações antes de administrar recursos públicos.');const result=Statecraft.act(s,type==='statePersonalSchedule'?(s.governments.presidente||Government.active(s)):Government.active(s),type,p,Government,()=>spend(s,0,0,18));if(result.ok)log(s,result.msg,'🏛️','politica');return result;}
 if(Government.actionTypes.includes(type)){const result=Government.act(s,type,p,()=>pay(0,18));if(result.ok)log(s,result.msg,'🏛️','politica');return result;}
 if(type==='nextYear'){const report=finishYear(s);return ok('Um novo ano começou.',{report});}
 if(type==='choose'){
  const e=EVENTS.find(x=>x.id===s.pending);const ch=e&&e.choices[Number(p.index)];if(!ch||!Number.isInteger(Number(p.index)))return fail('Escolha inválida.');
  const before=Systems.snapshot(s);if((err=pay(0,0,true)))return fail(err);const branch=effect(s,ch[1]);const text=Stories.outcomes[e.id]&&Stories.outcomes[e.id][Number(p.index)];let narrative=typeof text==='string'?text:text?(branch==='fail'?text.fail:text.success):'Sua decisão ganhou uma consequência na sua trajetória.';
  if(ch[1].friend&&s.people.length===before.people.length)narrative='A conversa aconteceu, mas seu círculo já está no limite desta versão. Nenhum novo contato foi adicionado; os outros efeitos da escolha estão registrados abaixo.';
  const trigger=Stories.triggers[e.id]&&Stories.triggers[e.id][Number(p.index)];let scheduled=false;if(trigger&&s.followups.length<32&&!s.followups.some(q=>q.id===trigger.id)){s.followups.push({id:trigger.id,dueYear:Math.min(9999,s.year+trigger.delay),sourceYear:s.year});scheduled=true;}
  s.cash=money(s.cash);s.debt=money(s.debt);const story={id:uid(s),event:e.id,year:s.year,age:s.age,title:e.title,icon:e.icon,choice:ch[0],narrative,changes:Systems.changes(s,before),followup:scheduled};s.stories.unshift(story);s.stories=s.stories.slice(0,60);s.pending=null;log(s,e.title+': '+narrative,e.icon,'escolha');if(worth(s)>=1e6)award(s,'million');return ok(narrative,{story});
 }else if(type==='deferEvent'){
  const e=EVENTS.find(x=>x.id===s.pending);if(!e)return fail('Não há uma decisão aberta.');s.hoursLeft=Math.max(0,s.hoursLeft-1);s.pending=null;msg='Você deixou esse acontecimento para outro momento.';log(s,e.title+': você preferiu deixar para outro momento.','🍃','escolha');
 }else if(type==='train'){
  const d=D.skills[p.id];if(!d)return fail('Habilidade desconhecida.');const intensity=['leve','normal','intenso'].includes(p.intensity)?p.intensity:'normal';const cost=Math.round(d.cost*(intensity==='intenso'?1.8:intensity==='leve'?.5:1));
  if((err=pay(cost,d.min,['xadrez','escrita','codigo','corrida','ciencia'].includes(p.id))))return fail(err);
  const supported=s.support.training>0;const gain=(integer(s,4,8)+(s.trait==='disciplinado'?2:0))*(intensity==='intenso'?1.45:intensity==='leve'?.7:1)*(supported?1.25:1)*World.trainingFactor(s,p.id)*Freedom.trainingFactor(s,p.id);if(supported)s.support.training--;addSkill(s,p.id,gain);
  const stat=D.stats[d.stat]?d.stat:'smarts';s.stats[stat]=clamp(s.stats[stat]+(intensity==='intenso'?3:2));if(intensity==='intenso')s.stats.health=clamp(s.stats.health-2);s.stats.happiness=clamp(s.stats.happiness+2);
  msg='Você treinou '+d.name+' e ganhou '+Math.round(gain)+' de habilidade.';log(s,msg,d.icon,'habilidade');
 }else if(type==='activity'){
  const choices={brincar:{min:0,cost:0,e:{happiness:8,fitness:2}},ler:{min:0,cost:0,e:{smarts:s.trait==='curioso'?8:6,happiness:2}},descansar:{min:0,cost:0,e:{health:(s.trait==='resiliente'?12:8)+Math.floor(s.skills.medicina/10),happiness:5}},exercicio:{min:6,cost:0,e:{fitness:7,health:4}},terapia:{min:12,cost:200,e:{happiness:14,health:3}},medico:{min:0,cost:s.age<18?0:money(350*(1-s.skills.medicina/250)),e:{health:17}},passeio:{min:6,cost:s.age<16?0:100,e:{happiness:10,charisma:3}},voluntario:{min:12,cost:0,e:{reputation:6,happiness:6,charisma:3}}};
  const c=choices[p.id];if(!c)return fail('Atividade desconhecida.');if((err=pay(c.cost,c.min,['ler','descansar','exercicio','terapia','medico'].includes(p.id))))return fail(err);effect(s,c.e);if(p.id==='ler'&&s.support.study>0){s.support.study--;effect(s,{smarts:3,grades:s.school.status==='cursando'?4:0});}msg='Você dedicou um tempo a '+({brincar:'brincar',ler:'ler e aprender',descansar:'descansar',exercicio:'se exercitar',terapia:'cuidar da mente',medico:'cuidar da saúde',passeio:'passear',voluntario:'ajudar outras pessoas'}[p.id])+'.';log(s,msg,'🌿');
 }else if(type==='study'){
  if(s.school.status==='cursando'){if((err=pay(0,6,true)))return fail(err);s.school.grades=clamp(s.school.grades+integer(s,8,14));s.stats.smarts=clamp(s.stats.smarts+(s.trait==='curioso'?5:4));msg='Você estudou e melhorou suas notas.';}
  else if(s.school.status==='incompleto'){if((err=pay(800,18,true)))return fail(err);s.school.status='concluido';msg='Você concluiu a equivalência do ensino médio. Novas portas estão abertas.';}
  else if(s.college){if((err=pay(0,18,true)))return fail(err);const c=find(D.degrees,s.college.id);addSkill(s,c.skill,5);s.stats.smarts=clamp(s.stats.smarts+3);msg='Você aprofundou seus estudos em '+c.name+'.';}else return fail('Você não está matriculado em um curso.');if(s.support.study>0){s.support.study--;effect(s,{smarts:3,grades:s.school.status==='cursando'?4:0});}log(s,msg,'📚','carreira');
 }else if(type==='dropSchool'){
  if(s.school.status!=='cursando')return fail('Você não está no ensino médio.');if((err=pay(0,16)))return fail(err);s.school.status='incompleto';msg='Você saiu da escola. Pode concluir a equivalência depois.';log(s,msg,'🎒','carreira');
 }else if(type==='college'){
  const c=find(D.degrees,p.id);if(!c)return fail('Curso desconhecido.');if(s.college)return fail('Você já está fazendo uma faculdade.');if(s.degrees.includes(c.id))return fail('Você já concluiu este curso.');if(s.school.status!=='concluido')return fail('Conclua o ensino médio primeiro.');
  if((err=pay(0,18)))return fail(err);const scholarship=s.stats.smarts>=78||s.school.grades>=85;s.college={id:c.id,progress:0,scholarship};msg='Você se matriculou em '+c.name+(scholarship?' com bolsa integral.':'. A cobrança será anual.');log(s,msg,c.icon,'carreira');
 }else if(type==='dropCollege'){
  if(!s.college)return fail('Você não está na faculdade.');if((err=pay()))return fail(err);s.college=null;msg='Você encerrou a matrícula da faculdade.';log(s,msg,'🎓','carreira');
 }else if(type==='applyJob'){
  if(s.politics.office)return fail('Encerre ou renuncie ao mandato antes de assumir outro trabalho.');const j=find(D.jobs,p.id);if(!j)return fail('Carreira desconhecida.');if(s.job===j.id&&!s.retired)return fail('Você já trabalha nessa carreira.');if(s.skills[j.skill]<j.req)return fail('Você precisa de '+j.req+' em '+D.skills[j.skill].name+'.');if(j.degree&&!s.degrees.includes(j.degree))return fail('É necessário diploma em '+find(D.degrees,j.degree).name+'.');if((err=pay(0,j.age)))return fail(err);
  s.job=j.id;s.jobLevel=1;s.performance=55+(s.support.referral>0?15:0);if(s.support.referral>0)s.support.referral--;s.retired=false;s.pension=0;award(s,'firstjob');msg='Você começou a trabalhar com '+j.name+'. O salário entra ao avançar o ano.';log(s,msg,j.icon,'carreira');
 }else if(type==='quitJob'){
  if(!s.job)return fail('Você não tem um emprego.');if((err=pay()))return fail(err);s.job=null;s.retired=false;s.pension=0;msg='Você deixou o emprego e abriu espaço para outro caminho.';log(s,msg,'🚪','carreira');
 }else if(type==='workHard'){
  if(!s.job||s.retired)return fail('Você precisa de um emprego ativo.');if((err=pay(0,16)))return fail(err);s.performance=clamp(s.performance+15);s.stats.health=clamp(s.stats.health-2);msg='Você se dedicou ao trabalho. Desempenho +15.';log(s,msg,'💼','carreira');
 }else if(type==='workload'){
  if(!['leve','equilibrado','intenso'].includes(p.id))return fail('Ritmo inválido.');if((err=pay()))return fail(err);s.workload=p.id;msg='Ritmo de trabalho alterado.';
 }else if(type==='retire'){
  if(!s.job||s.retired)return fail('Você precisa de um emprego ativo.');if(s.age<60)return fail('A aposentadoria fica disponível aos 60 anos.');if((err=pay()))return fail(err);s.pension=money(salary(s)*Math.min(.65,.2+s.jobYears*.012));s.retired=true;msg='Você se aposentou. Sua renda anual será de R$ '+s.pension.toLocaleString('pt-BR')+'.';log(s,msg,'🌴','carreira');
 }else if(type==='project'){
  const d=find(D.projects,p.id);if(!d)return fail('Projeto desconhecido.');if((err=pay(d.cost,d.min)))return fail(err);let earned=money(d.base*(.35+s.skills[d.skill]/18)*(.6+rand(s)*1.1)*(s.trait==='criativo'?1.25:1)*World.projectFactor(s,d.skill));if(s.support.project>0){s.support.project--;earned=money(earned*1.25);}const incomeTax=Government.personalTax(s,earned);s.cash=M.add(s.cash,earned-incomeTax);addSkill(s,d.skill,3);s.fame=clamp(s.fame+2);msg='Projeto concluído. Você recebeu R$ '+(earned-incomeTax).toLocaleString('pt-BR')+(incomeTax?' líquidos (IRPF: R$ '+incomeTax.toLocaleString('pt-BR')+')':'')+'.';log(s,d.name+': recebeu R$ '+(earned-incomeTax).toLocaleString('pt-BR')+(incomeTax?' após IRPF.':'.'),d.icon,'dinheiro');
 }else if(type==='startBusiness'){
  const d=find(D.businesses,p.id);if(!d)return fail('Negócio desconhecido.');if(s.businesses.length>=200)return fail('Você atingiu o limite de empresas desta versão.');if((err=pay(d.cost,18)))return fail(err);s.businesses.push({id:uid(s),type:d.id,level:1,strategy:'equilibrio',last:0});award(s,'business');msg='Você abriu '+d.name+'. O resultado aparece no fechamento de cada ano.';log(s,msg,d.icon,'dinheiro');
 }else if(type==='upgradeBusiness'){
  const b=s.businesses.find(x=>x.id===p.id);if(!b)return fail('Negócio não encontrado.');const d=find(D.businesses,b.type);if(b.level>=100)return fail('Esse negócio atingiu o nível máximo desta versão.');const c=money(d.cost*Math.pow(b.level,1.3)*.8);if((err=pay(c,18)))return fail(err);b.level++;addSkill(s,'negocios',2);msg=d.name+' cresceu para o nível '+b.level+'.';log(s,msg,'📈','dinheiro');
 }else if(type==='businessStrategy'){
  const b=s.businesses.find(x=>x.id===p.id);if(!b||!['equilibrio','qualidade','escala'].includes(p.strategy))return fail('Estratégia inválida.');if((err=pay(0,18)))return fail(err);b.strategy=p.strategy;msg='Estratégia do negócio alterada.';
 }else if(type==='sellBusiness'){
  const i=s.businesses.findIndex(x=>x.id===p.id);if(i<0)return fail('Negócio não encontrado.');if((err=pay(0,18)))return fail(err);const b=s.businesses[i];const value=money(find(D.businesses,b.type).cost*b.level*.7);s.cash=M.add(s.cash,value);s.businesses.splice(i,1);msg='Negócio vendido por R$ '+value.toLocaleString('pt-BR')+'.';log(s,msg,'🏷️','dinheiro');
 }else if(type==='meet'){
  if(!canAddFriend(s))return fail('Seu círculo chegou ao limite de 512 amizades ou ao limite total de contatos.');const circle=own(World.circles,p.circle||'bairro')?World.circles[p.circle||'bairro']:null;if(!circle)return fail('Encontro desconhecido.');if(World.influence(s).popularity<circle.pop)return fail('Você precisa de popularidade '+circle.pop+' para entrar neste encontro.');if((err=pay(s.age>=18||p.circle&&p.circle!=='bairro'?circle.cost:0,circle.min)))return fail(err);const pe=person(s,'friend',Math.max(circle.min,s.age+integer(s,-3,3)));pe.popularity=integer(s,circle.low,circle.high);if(circle.career)pe.career=circle.career;if(p.circle==='celebridades'&&pe.career==='comum')pe.career='cinema';s.people.push(pe);s.stats.charisma=clamp(s.stats.charisma+3);msg='Você conheceu '+pe.name+'.';log(s,msg,'👋','pessoas');
 }else if(type==='date'){
  if(partner(s))return fail('Você já está em um relacionamento.');if(s.people.length>=D.MAX_PEOPLE)return fail('Seu círculo chegou ao limite desta versão.');if((err=pay(160,18)))return fail(err);const pe=person(s,'partner',Math.max(18,s.age+integer(s,-5,5)));pe.bond=60+(s.trait==='sociavel'?10:0);s.people.push(pe);s.stats.happiness=clamp(s.stats.happiness+8);msg='Você começou a namorar '+pe.name+'.';log(s,msg,'💛','pessoas');
 }else if(type==='interact'||type==='interactAll'){
  const d=interaction(s,p.action);if(!d)return fail('Ação desconhecida.');
  if(type==='interactAll'){
   const quote=groupQuote(s,p.action);if(!quote.count)return fail('Ninguém com vínculo abaixo de 100 precisa dessa ação agora.');
   if((err=spend(s,quote.hours,quote.cost,0,quote.inPrison)))return fail(err);
   const ids=new Set(quote.ids);for(const pe of s.people)if(ids.has(pe.id))applyInteraction(s,pe,d);
   msg='Você '+d.verb+' '+quote.count+' pessoa(s). Foram '+quote.hours+' h'+(quote.cost?' e R$ '+quote.cost.toLocaleString('pt-BR'):'')+'.';log(s,msg,d.icon,'pessoas');
  }else{
   const pe=s.people.find(x=>x.id===p.id&&x.alive);if(!pe)return fail('Pessoa indisponível.');if((err=pay(d.cost,0,p.action==='conversar')))return fail(err);
   applyInteraction(s,pe,d);msg='Você '+d.verb+' '+pe.name+'. Foram '+d.hours+' h.';log(s,msg,d.icon,'pessoas');
  }
 }else if(type==='romanceFriend'){
  const pe=s.people.find(x=>x.id===p.id&&x.kind==='friend'&&x.alive);if(!pe)return fail('Amizade não encontrada.');if(partner(s))return fail('Você já está em um relacionamento.');if(pe.age<18)return fail('O outro personagem precisa ter 18 anos.');if(pe.bond<65)return fail('Aprofunde a amizade primeiro: vínculo 65.');if((err=pay(0,18)))return fail(err);contact(s,pe);if(rand(s)<.35){pe.bond=clamp(pe.bond-3);msg=pe.name+' prefere continuar só na amizade.';}else{pe.kind='partner';msg='Você e '+pe.name+' começaram a namorar.';}log(s,msg,'💛','pessoas');
 }else if(type==='marry'){
  const pe=partner(s);if(!pe||pe.kind==='spouse')return fail('Você precisa estar namorando.');if(pe.bond<70)return fail('Fortaleça o vínculo até 70 antes de casar.');if((err=pay(2500,18)))return fail(err);pe.kind='spouse';contact(s,pe);s.stats.happiness=clamp(s.stats.happiness+12);msg='Você e '+pe.name+' se casaram.';log(s,msg,'💍','pessoas');
 }else if(type==='breakup'){
  const pe=partner(s);if(!pe)return fail('Você não está em um relacionamento.');if((err=pay(pe.kind==='spouse'?1000:0,18)))return fail(err);pe.kind='ex';contact(s,pe);pe.bond=clamp(pe.bond-30);s.stats.happiness=clamp(s.stats.happiness-8);msg='Seu relacionamento com '+pe.name+' terminou.';log(s,msg,'🍂','pessoas');
 }else if(type==='child'){
  if(s.people.length>=D.MAX_PEOPLE)return fail('Seu círculo chegou ao limite desta versão.');const adopt=!!p.adopt;if(!adopt&&!partner(s))return fail('Você precisa de um relacionamento ou pode escolher adoção.');if(!adopt&&s.age>55)return fail('Nesta fase, você pode ampliar a família por adoção.');if((err=pay(adopt?1800:1200,18)))return fail(err);const pe=person(s,'child',adopt?Number(p.age)===8?8:Number(p.age)===4?4:0:0);pe.name=String(p.name||pe.name).trim().slice(0,36)||pe.name;pe.bond=85;s.people.push(pe);award(s,'family');s.stats.happiness=clamp(s.stats.happiness+12);msg=pe.name+(adopt?' chegou à sua família por adoção.':' nasceu. Um novo capítulo da sua família começou.');log(s,msg,'🌱','pessoas');
 }else if(type==='help'){
  if(s.yearFlags.help)return fail('Você já pediu ajuda neste ano.');if(!s.people.some(x=>x.kind==='parent'&&x.alive))return fail('Não há apoio familiar disponível.');if((err=pay(0,6)))return fail(err);s.yearFlags.help=true;s.people.filter(x=>x.kind==='parent'&&x.alive).forEach(x=>contact(s,x));const amount=money(D.origins[s.origin].support*(.5+rand(s)));s.cash=M.add(s.cash,amount);msg='Sua família ajudou com R$ '+amount.toLocaleString('pt-BR')+'.';log(s,msg,'🤲','dinheiro');
 }else if(type==='claimFavor'||type==='claimAllFavors'){
  const items=type==='claimFavor'?[Systems.favorQuote(s,p.id)].filter(Boolean):Systems.favorList(s);if(!items.length)return fail('Nenhum favor disponível: precisa de amizade viva em 100 e ainda não usada neste ano.');const hours=items.reduce((n,x)=>n+x.hours,0);if((err=spend(s,hours,0,6,true)))return fail(err);
  for(const item of items){const pe=s.people.find(x=>x.id===item.id);pe.lastFavorYear=s.year;contact(s,pe);s.support[item.benefit]++;}msg=items.length===1?items[0].name+' ofereceu apoio. '+items[0].description:items.length+' apoios recebidos. Os benefícios estão disponíveis até o fechamento deste ano.';log(s,msg,'🤝','pessoas');return ok(msg,{supportReceipt:{items,hours}});
 }else if(type==='startCampaign'){
  if(s.politics.office)return fail('Renuncie ou conclua o mandato atual para iniciar outra candidatura.');if(s.politics.campaign)return fail('Você já tem uma campanha aberta.');if(s.politics.lastElectionYear===s.year)return fail('Você já disputou uma eleição neste ano.');if(!['base','ampla'].includes(p.budget||'base'))return fail('Orçamento inválido.');const q=World.campaignQuote(s,p.id,p.budget||'base');if(!q)return fail('Cargo desconhecido.');const blocked=Government.Civic.electionBlock(s,p.id);if(blocked)return fail(blocked);if(s.skills.politica<q.req)return fail('Desenvolva Política até '+q.req+' para esta candidatura.');if((err=pay(q.cost,q.min)))return fail(err);s.politics.campaign={id:q.id,budget:q.budget,effort:0,year:s.year};msg='Campanha para '+q.name+' iniciada. Mobilize apoiadores, faça debates e depois abra a votação.';log(s,msg,'🗳️','politica');
 }else if(type==='campaignAction'){
  const c=s.politics.campaign;if(!c)return fail('Inicie uma campanha primeiro.');if(!['comicio','debate'].includes(p.id))return fail('Ação de campanha inválida.');if(c.effort>=6)return fail('Sua campanha já fez as seis ações disponíveis. Abra a votação.');if((err=pay(p.id==='comicio'?500:0,18)))return fail(err);c.effort++;addSkill(s,p.id==='debate'?'oratoria':'politica',3);s.fame=clamp(s.fame+1);msg=p.id==='debate'?'Você apresentou suas propostas no debate. Oratória +3; a campanha ganhou força.':'O comício reuniu apoiadores. Política +3; sua visibilidade cresceu.';log(s,msg,'🎙️','politica');
 }else if(type==='holdElection'){
  const c=s.politics.campaign;if(!c)return fail('Não há campanha aberta.');const target=find(World.offices,c.id);if(s.age<target.min||s.skills.politica<target.req)return fail('Você precisa manter os requisitos de idade e Política para disputar este cargo.');if(s.politics.lastElectionYear===s.year)return fail('Você já disputou uma eleição neste ano.');if((err=pay(0,18)))return fail(err);const forecast=World.electionForecast(s),d=find(World.offices,c.id),votes=Math.round(clamp(forecast.votes+integer(s,-600,600)/100,2,98)*100)/100,won=votes>50,opponent=pick(s,D.names)+' '+pick(s,D.surnames),receipt={id:c.id,year:s.year,votes,won,opponent};s.politics.elections.unshift(receipt);s.politics.elections=s.politics.elections.slice(0,30);s.politics.lastElectionYear=s.year;s.politics.campaign=null;if(won){s.politics.office={id:d.id,remaining:Government.Civic.termRules(s,d.id).termYears,approval:clamp(50+s.reputation*.2)};Government.initialize(s,d.id);s.job=null;s.retired=false;s.pension=0;s.reputation=clamp(s.reputation+3);s.fame=clamp(s.fame+8);award(s,'elected');if(d.id==='presidente')award(s,'president');}msg=(won?'Você foi eleito para '+d.name:'Você perdeu a eleição para '+d.name)+', com '+votes.toLocaleString('pt-BR')+'% dos votos. '+(won?'Seu mandato dura '+s.politics.office.remaining+' anos.':'Outra candidatura poderá começar no próximo ano.');log(s,msg,'🗳️','politica');return ok(msg,{election:receipt});
 }else if(type==='govern'){
  const office=s.politics.office;if(!office)return fail('Você precisa estar em um mandato.');if(s.politics.policyYear===s.year)return fail('Você já executou uma política pública neste ano.');const d=World.policies[p.id];if(!d)return fail('Política pública desconhecida.');if((err=pay(0,18)))return fail(err);const quality=World.policyStrength(s),gain=Math.round(2+quality*10),rep=Math.round(1+quality*5);office.approval=clamp(office.approval+gain);s.reputation=clamp(s.reputation+rep);s.fame=clamp(s.fame+2);s.politics.policyYear=s.year;addSkill(s,'politica',3);addSkill(s,'lideranca',2);msg='Você prestou contas da execução de '+d.name.toLowerCase()+'. Aprovação +'+gain+'; reputação +'+rep+'. O orçamento e os projetos seguem o plano anual.';log(s,msg,d.icon,'politica');
 }else if(type==='resignOffice'){
  if(!s.politics.office)return fail('Você não está em um mandato.');if((err=pay(0,18)))return fail(err);s.politics.office=null;msg='Você renunciou ao mandato e pode escolher outra carreira ou candidatura.';log(s,msg,'🏛️','politica');
 }else if(type==='cancelCampaign'){
  if(!s.politics.campaign)return fail('Não há campanha aberta.');if((err=pay(0,18)))return fail(err);s.politics.campaign=null;msg='Você encerrou a campanha. O orçamento utilizado não foi devolvido.';log(s,msg,'🗳️','politica');
 }else if(type==='tradeCrypto'){
  const q=World.tradeQuote(s,p.id,p.operation,p.amount,p.mode||'reais');if(!q)return fail('Informe um valor positivo ou uma quantidade com até oito casas decimais.');if(q.price===0&&p.operation!=='sellAll')return fail('Esta moeda perdeu todo o valor e não pode mais ser negociada.');if(Number(q.units)<=0)return fail('Não há unidades disponíveis para esta operação.');if(p.operation!=='buy'&&World.unitAtoms(q.units)>World.unitAtoms(s.market.holdings[p.id]))return fail('Você não tem unidades suficientes.');if(q.overSupply)return fail('A compra supera a oferta total de '+q.supply.toLocaleString('pt-BR')+' moedas.');if(q.willCollapse&&p.confirmConcentration!==true)return {ok:false,msg:'Esta compra ultrapassa 50% da oferta e derruba a moeda permanentemente a zero.',needsConcentrationConfirmation:true};if((err=pay(p.operation==='buy'?q.total:0,16)))return fail(err);s.market.holdings[p.id]=q.after;if(p.operation!=='buy')s.cash=M.add(s.cash,q.total);if(q.willCollapse)s.market.collapsed[p.id]={age:s.age,year:s.year};s.market.trades.unshift({id:p.id,operation:p.operation,age:s.age,price:q.price,units:q.units,total:q.total});s.market.trades=s.market.trades.slice(0,40);msg=(p.operation==='buy'?'Compra':'Venda')+' de '+World.coinInfo(s,p.id).name+': R$ '+M.format(q.total)+'.'+(q.willCollapse?' Sua concentração ultrapassou 50% da oferta. A moeda perdeu todo o valor permanentemente.':'');log(s,msg,'🪙','dinheiro');
 }else if(type==='setTransport'){
  if(!['auto','none'].includes(p.id)&&!s.assets.some(a=>a.id===p.id&&own(D.vehicles,a.type)))return fail('Transporte indisponível.');s.transport=p.id;msg=p.id==='none'?'Deslocamentos sem veículo próprio.':p.id==='auto'?'O melhor veículo próprio será usado em cada tipo de trajeto.':'Transporte principal selecionado.';
 }else if(type==='buyAsset'){
  const a=find(D.assets,p.id);if(!a)return fail('Bem desconhecido.');if(s.assets.length>=500)return fail('Você atingiu o limite de bens desta versão.');const transferTax=find(D.assets,a.id).type==='vehicle'?0:Government.assess(s,'itbi',a.cost);if((err=pay(a.cost+transferTax,18)))return fail(err);s.assets.push({id:uid(s),type:a.id,value:a.cost});s.stats.happiness=clamp(s.stats.happiness+(a.joy||2));msg='Você comprou '+a.name+'.';log(s,msg,a.icon,'dinheiro');
 }else if(type==='sellAsset'){
  const i=s.assets.findIndex(x=>x.id===p.id);if(i<0)return fail('Bem não encontrado.');if((err=pay(0,18)))return fail(err);const a=s.assets[i],value=money(a.value*.92);s.cash=M.add(s.cash,value);s.assets.splice(i,1);if(s.transport===a.id)s.transport='auto';msg='Você vendeu '+find(D.assets,a.type).name+' por R$ '+value.toLocaleString('pt-BR')+'.';log(s,msg,'🏷️','dinheiro');
 }else if(type==='invest'||type==='withdraw'){
  if(type==='invest'&&p.id==='cripto')return fail('Agora você pode escolher moedas individuais no mercado de criptomoedas. O saldo antigo continua disponível para resgate.');const inv=find(D.investments,p.id);const amount=M.input(p.amount);if(!inv||amount===null||M.cmp(amount,0)<=0)return fail('Informe um valor válido.');if(s.age<18)return fail('Investimentos ficam disponíveis aos 18 anos.');if(type==='invest'){if((err=pay(amount,18)))return fail(err);s.investments[p.id]=M.add(s.investments[p.id],amount);msg='Você investiu R$ '+amount.toLocaleString('pt-BR')+' em '+inv.name+'.';}else{if(M.cmp(s.investments[p.id],amount)<0)return fail('Você não tem esse valor aplicado.');if((err=pay(0,18)))return fail(err);s.investments[p.id]=M.sub(s.investments[p.id],amount);s.cash=M.add(s.cash,amount);msg='Você resgatou R$ '+amount.toLocaleString('pt-BR')+'.';}log(s,msg,inv.icon,'dinheiro');
 }else if(type==='loan'){
  const amount=M.input(p.amount),limit=M.max(5000,M.add(M.mul(salary(s),.8),M.mul(M.max(0,worth(s)),.2)));if(amount===null||M.cmp(amount,100)<0||M.cmp(M.add(amount,s.debt),limit)>0)return fail('O limite disponível é R$ '+M.format(M.max(0,M.sub(limit,s.debt)))+'.');if((err=pay(0,18)))return fail(err);s.cash=M.add(s.cash,amount);s.debt=M.add(s.debt,amount);msg='Você tomou R$ '+M.format(amount)+' de crédito, a 12% ao ano.';log(s,msg,'🏦','dinheiro');
 }else if(type==='repay'){
  const amount=M.input(p.amount);if(amount===null||M.cmp(amount,0)<=0)return fail('Informe um valor válido.');const value=M.min(s.debt,amount);if(M.cmp(value,0)<=0)return fail('Você não tem dívida.');if((err=pay(value,18,true)))return fail(err);s.debt=M.sub(s.debt,value);msg='Você pagou R$ '+M.format(value)+' da dívida.';log(s,msg,'✅','dinheiro');
 }else if(type==='lifestyle'){
  if(!find(D.lifestyles,p.id))return fail('Estilo inválido.');if(s.age<18)return fail('Você poderá escolher seu padrão de vida aos 18.');if((err=pay(0,18)))return fail(err);s.lifestyle=p.id;msg='Seu padrão de vida foi alterado.';
 }else if(type==='move'){
  const c=find(D.cities,p.id);if(!c||c.id===s.city)return fail('Escolha outra cidade.');if((err=pay(c.id==='exterior'?12000:2200,18)))return fail(err);s.city=c.id;award(s,'traveler');msg='Você se mudou para '+c.name+'. Custos e oportunidades mudaram.';log(s,msg,'🧭');
 }else if(type==='adventure'){
  if(p.id==='oportunidade'){if((err=pay(0,12)))return fail(err);newEvent(s);return ok('Uma possibilidade apareceu.');}
  const choices={viagem:{min:18,cost:1800,e:{happiness:18,smarts:4}},festival:{min:16,cost:300,e:{happiness:12,charisma:4,friend:true}},empreender:{min:12,cost:0,e:{skill:'negocios',gain:7,smarts:2}},desafio:{min:16,cost:100,e:{fitness:8,health:-3,happiness:8}}};const c=choices[p.id];if(!c)return fail('Aventura desconhecida.');if((err=pay(c.cost,c.min)))return fail(err);effect(s,c.e);msg='Você saiu da rotina e viveu uma nova experiência.';log(s,msg,'🧭');
 }else if(type==='risk'){
  const national=s.governments.presidente,reparative=!!(national&&Justice.active(national));
  if(!['delito','contrabando','acusacao_falsa'].includes(p.id)||p.id==='acusacao_falsa'&&!reparative)return fail('Escolha um evento arriscado disponível.');
  if(s.yearFlags.risk)return fail('Você já se arriscou neste ano.');if((err=pay(0,18)))return fail(err);s.yearFlags.risk=true;
  const malicious=p.id==='acusacao_falsa',chance=p.id==='contrabando'?.58:malicious?.65:.3,gain=p.id==='contrabando'?integer(s,7000,22000):integer(s,300,2400);let restitutionReceipt=null;
  if(rand(s)<chance){s.record++;s.reputation=clamp(s.reputation-18);
   if(p.id!=='contrabando'&&Government.restitutionEnabled(s)){
    if(reparative){restitutionReceipt=Justice.addPersonal(s,malicious?'acusacao_deliberada':'patrimonial',gain,national.civic.justice);msg=(malicious?'A falsidade deliberada foi comprovada.':'O dano patrimonial foi comprovado.')+' Reparação de '+restitutionReceipt.multiplier+'×: R$ '+M.format(restitutionReceipt.owed)+'. Pagos à vítima: R$ '+M.format(restitutionReceipt.paid)+'. Saldo: R$ '+M.format(restitutionReceipt.remaining)+'.';
    }else{const multiplier=national.civic.justice.multiplier,owed=money(gain*multiplier),paid=M.min(s.cash,owed),remaining=M.sub(owed,paid);s.cash=M.sub(s.cash,paid);s.debt=M.add(s.debt,remaining);restitutionReceipt={damage:gain,owed,paid,remaining};msg='A infração patrimonial foi apurada. Você deve R$ '+M.format(owed)+' à vítima: R$ '+M.format(paid)+' pagos agora'+(M.cmp(remaining,0)>0?' e R$ '+M.format(remaining)+' em dívida pessoal.':'.');}
   }else{s.politics.office=null;s.politics.campaign=null;s.prison=p.id==='contrabando'?3:1;s.job=null;s.retired=false;msg='Você foi detido. Pena de '+s.prison+' ano(s).';}
  }else{s.cash=M.add(s.cash,gain);s.reputation=clamp(s.reputation-8);msg='Você ganhou R$ '+M.format(gain)+', mas colocou sua liberdade e reputação em risco.';}
  log(s,msg,'⚖️');if(restitutionReceipt)return ok(msg,{restitution:restitutionReceipt});
 }else if(type==='lawyer'){
  if(!s.prison)return fail('Você não está cumprindo pena.');if(s.yearFlags.lawyer)return fail('Você já recorreu neste ano.');if((err=pay(2500,18,true)))return fail(err);s.yearFlags.lawyer=true;if(rand(s)<.6){s.prison=Math.max(0,s.prison-1);msg=s.prison?'O recurso reduziu sua pena em um ano.':'O recurso foi aceito. Você recuperou a liberdade.';}else msg='O recurso foi negado desta vez.';log(s,msg,'⚖️');
 }else if(type==='enterTournament'){
  const d=find(D.tournaments,p.id),ti=Number(p.tier),tier=D.tiers[ti];if(!d||!tier||!Number.isInteger(ti))return fail('Competição inválida.');if(s.skills[d.skill]<tier.req)return fail('Você precisa de '+tier.req+' em '+D.skills[d.skill].name+'.');if(s.rankings[d.id]<tier.points)return fail('Você precisa de '+tier.points+' pontos no circuito. Dispute níveis anteriores.');const ticket=d.id+':'+ti;if(s.tournamentYear[ticket])return fail('Você já disputou esta edição. Outra abre no próximo ano.');if(s.hoursLeft<tournamentDuration(ti,s))return fail('Reserve '+tournamentDuration(ti,s)+' h para completar esta competição. As horas serão descontadas apenas conforme você avançar.');if((err=pay(tier.fee,d.min)))return fail(err);s.tournamentYear[ticket]=true;
  s.tournament={id:d.id,tier:ti,round:0,stamina:100,opponents:Array.from({length:tier.rounds},(_,i)=>({name:pick(s,D.names)+' '+pick(s,D.surnames),power:clamp(tier.power+integer(s,-5,5)+i*4,5,99),style:pick(s,['agressivo','tecnico','defensivo'])})),results:[],prize:tier.prize};msg='Inscrição confirmada. Sua chave está pronta!';log(s,'Você entrou no '+d.name+' · '+tier.name+'.',d.icon,'torneio');
 }else if(type==='round'){
  const t=s.tournament;if(!t)return fail('Não há torneio em andamento.');if(!['agressivo','tecnico','defensivo'].includes(p.strategy))return fail('Escolha uma estratégia.');const d=find(D.tournaments,t.id),tier=D.tiers[t.tier],op=t.opponents[t.round];
  const preview=World.battle(s,p.strategy);if((err=pay()))return fail(err);
  const chance=preview.chance;const won=preview.guaranteed||rand(s)<chance;const roll=integer(s,1,3);const result={round:t.round,opponent:op.name,won,score:won?(3+roll)+' × '+roll:roll+' × '+(3+roll),strategy:p.strategy,guaranteed:preview.guaranteed,chance};t.results.push(result);t.stamina=clamp(t.stamina-(p.strategy==='agressivo'?29:p.strategy==='tecnico'?20:12));addSkill(s,d.skill,2);t.round++;
  let finished=!won||t.round>=tier.rounds;let champion=won&&finished;let payout=0;let points=0;if(finished){const wins=t.results.filter(r=>r.won).length;points=champion?Systems.CHAMPION_POINTS[t.tier]:Math.max(8,wins*[12,25,50,90][t.tier]);payout=champion?t.prize:wins>=tier.rounds-1?money(t.prize*.22):wins>0?money(t.prize*.06):0;s.cash=M.add(s.cash,payout);s.rankings[d.id]+=points;s.fame=clamp(s.fame+(champion?(t.tier+1)*5:1));s.medals.unshift({id:uid(s),sport:t.id,tier:t.tier,age:s.age,champion,position:champion?'Campeão':wins>=tier.rounds-1?'Finalista':'Participante',prize:payout,points});s.medals=s.medals.slice(0,150);if(champion){award(s,'champion');if(t.tier===3){award(s,'world');if(!s.mastered.includes(t.id)){s.mastered.push(t.id);log(s,'Você conquistou domínio de '+d.name+'. As vitórias automáticas do circuito estão liberadas.','🌎','torneio');}}}msg=(champion?'Você venceu o campeonato!':won?'Você avançou!':'Sua participação terminou.')+' +'+points+' pontos'+(payout?' · R$ '+payout.toLocaleString('pt-BR'):'')+'.';log(s,find(D.tournaments,t.id).name+' · '+tier.name+': '+(champion?'título conquistado':wins+' vitória(s)')+'. '+msg,champion?'🏆':'🏅','torneio');s.tournament=null;}else msg='Vitória contra '+op.name+'! Você avançou para a próxima rodada.';
  s.lastResult={type:'tournament',result,champion,finished,payout,points,id:d.id,tier:t.tier};return ok(msg,{competition:s.lastResult});
 }else if(type==='autoSweep'){
  const d=find(D.tournaments,p.id);if(!d)return fail('Modalidade desconhecida.');const quote=Systems.sweepQuote(s,p.id);if(!quote.unlocked)return fail('Vença o mundial desta modalidade para liberar o domínio do circuito.');if(!quote.count)return fail('Todas as edições desta modalidade já foram disputadas neste ano.');if((err=spend(s,quote.hours,quote.cost,d.min)))return fail(err);
  for(const item of quote.items){s.tournamentYear[d.id+':'+item.tier]=true;s.cash=M.add(s.cash,item.prize);s.rankings[d.id]+=item.points;s.fame=clamp(s.fame+(item.tier+1)*5);addSkill(s,d.skill,item.rounds*2);s.medals.unshift({id:uid(s),sport:d.id,tier:item.tier,age:s.age,champion:true,position:'Campeão por domínio',prize:item.prize,points:item.points});}s.medals=s.medals.slice(0,150);award(s,'champion');award(s,'world');if(worth(s)>=1e6)award(s,'million');msg='Você venceu '+quote.count+' campeonato(s) de '+d.name+' por domínio. '+quote.hours+' h, inscrições de R$ '+quote.cost.toLocaleString('pt-BR')+' e prêmios de R$ '+quote.prize.toLocaleString('pt-BR')+'.';log(s,msg,'🏆','torneio');return ok(msg,{sweep:quote});
 }else if(type==='forfeit'){
  if(!s.tournament)return fail('Não há torneio em andamento.');log(s,'Você abandonou o torneio. A inscrição não foi devolvida.','🏳️','torneio');s.tournament=null;msg='Você saiu do torneio.';
 }else if(type==='sandbox'){
  if(p.enable!==undefined){s.sandbox=!!p.enable;msg=s.sandbox?'Modo livre ativado. O editor está disponível; ações continuam consumindo horas.':'Modo de vida ativado. O orçamento anual continua em horas.';}
  else{if(!s.sandbox)return fail('Ative o modo livre primeiro.');const n=Number(p.value);if(!Number.isFinite(n))return fail('Informe um número válido.');if(p.field==='cash'||p.field==='debt'){const value=M.input(p.value);if(value===null)return fail('Informe um valor monetário válido.');s[p.field]=value;}else if(p.field==='hoursLeft')s.hoursLeft=Math.round(clamp(n,0,D.YEAR_HOURS));else if(p.field==='age'){s.age=Math.round(clamp(n,0,119));if(s.age>=18&&s.school.status==='infancia')s.school.status='concluido';}else if(own(D.skills,p.field)){s.skills[p.field]=clamp(n);if(s.skills[p.field]>=100)award(s,'master');}else if(own(D.stats,p.field))s.stats[p.field]=clamp(n);else if(p.field==='ranking')for(const k of Object.keys(s.rankings))s.rankings[k]=Math.round(clamp(n,0,1e6));else if(p.field==='prison'){s.prison=Math.round(clamp(n,0,100));if(s.prison){s.politics.office=null;s.politics.campaign=null;}}else return fail('Campo desconhecido.');s.alive=true;msg='Seu mundo foi atualizado.';}
 }else if(type==='legacy'){
  if(s.alive)return fail('A continuação por descendente abre quando esta vida termina.');const child=s.people.find(x=>x.id===p.id&&x.kind==='child'&&x.alive);if(!child)return fail('Descendente indisponível.');const total=M.max(0,worth(s));const heirs=children(s);const share=M.quotient(total,Math.max(1,heirs.length)),inheritance=M.sub(share,Government.assess(s,'itcmd',share));const next=create({name:child.name,age:[0,6,16,18].includes(child.age)?child.age:18,origin:'comum',trait:s.trait,seed:s.seed,sandbox:s.sandbox,pronoun:s.pronoun});next.governments=JSON.parse(JSON.stringify(s.governments));next.politicalWorld=JSON.parse(JSON.stringify(s.politicalWorld));next.timelines=JSON.parse(JSON.stringify(s.timelines));next.age=Math.min(120,child.age);next.seq=Math.max(next.seq,s.seq);next.year=s.year;next.cash=inheritance;next.generation=s.generation+1;next.ancestors=[{name:s.name,age:s.age,worth:worth(s)},...s.ancestors].slice(0,30);next.achievements=s.achievements.slice();next.people=heirs.filter(x=>x.id!==child.id).map(x=>({...x,kind:'sibling'}));next.school.status=next.age<6?'infancia':next.age<18?'cursando':'concluido';award(next,'legacy');log(next,'Você continua a história por '+next.name+'. Herança líquida: R$ '+inheritance.toLocaleString('pt-BR')+'.','📜');Object.keys(s).forEach(k=>delete s[k]);Object.assign(s,next);return ok('A próxima geração começou.');
 }else return fail('Ação desconhecida.');
 s.cash=money(s.cash);if(worth(s)>=1e6)award(s,'million');return ok(msg);
}
function validate(raw){
 const reject=()=>{throw new Error('Arquivo de progresso inválido ou incompatível.');};
 const num=(n,a=0,b=1e12)=>typeof n==='number'&&Number.isFinite(n)&&n>=a&&n<=b;
 const str=(v,n=500)=>typeof v==='string'&&v.length<=n;
 if(!raw||raw.game!=='vida-aberta'||![1,2,3,4,5,6,7,8,9,10,11,12].includes(raw.version)||!str(raw.name,36)||!raw.name.trim()||!num(raw.age,0,150)||!Number.isInteger(raw.age)||!num(raw.year,0,10000)||!num(raw.seed,1,4294967295)||!num(raw.seq,0,1e8)||!own(D.origins,raw.origin)||!own(D.traits,raw.trait)||!find(D.cities,raw.city)||typeof raw.alive!=='boolean'||typeof raw.sandbox!=='boolean')reject();
 const s=JSON.parse(JSON.stringify(raw));
 if(s.version===1){if(!num(s.actions,0,12))reject();s.hoursLeft=Math.round(s.actions/12*D.YEAR_HOURS);if(Array.isArray(s.people))s.people.forEach(p=>{if(p&&typeof p==='object')p.lastContactYear=s.year;});s.version=2;delete s.actions;}
 if(s.version===2){s.support=Systems.emptySupport();s.transport='auto';s.stories=[];s.followups=[];s.mastered=Array.isArray(s.medals)?[...new Set(s.medals.filter(m=>m&&m.champion&&m.tier===3).map(m=>m.sport))]:[];if(Array.isArray(s.people))s.people.forEach(p=>{if(p&&typeof p==='object'){p.specialty=Systems.specialtyFor(p);p.lastFavorYear=-1;}});s.version=3;}
 if(s.version===3){if(!s.skills||typeof s.skills!=='object')reject();for(const k of World.NEW_SKILLS)s.skills[k]=s.age>=16?8:0;s.politics=World.emptyPolitics();s.market=World.emptyMarket(s.seed);if(Array.isArray(s.people))s.people.forEach(p=>{if(p&&typeof p==='object')Object.assign(p,World.socialDefaults(p));});s.version=4;}
 if(s.version===4){s.governments={};if(s.politics&&s.politics.office&&Government.roles.includes(s.politics.office.id))Government.initialize(s,s.politics.office.id);s.version=5;}
 if(s.version===5){if(!s.governments||typeof s.governments!=='object'||Array.isArray(s.governments))reject();for(const g of Object.values(s.governments))Government.Ops.initialize(g);Government.syncJustice(s);s.version=6;}
 if(s.version===6){if(!s.governments||typeof s.governments!=='object'||Array.isArray(s.governments))reject();for(const g of Object.values(s.governments))Government.Citizens.initialize(g);s.version=7;}
 if(s.version===7){if(!s.governments||typeof s.governments!=='object'||Array.isArray(s.governments))reject();for(const g of Object.values(s.governments))Government.Civic.initialize(g,s.seed);s.civicLife=Government.Civic.emptyLife();Government.syncJustice(s);s.version=8;}
 if(s.version===8){const a=World.migrateMarket(s);s.publicFunding={};if(M.cmp(a.recovered,0)>0||M.cmp(a.liquidated,0)>0)log(s,'Ajuste da economia: R$ '+M.format(a.recovered)+' recuperados de vendas cortadas pelo limite antigo e R$ '+M.format(a.liquidated)+' de posições antigas acima de 50% liquidadas pela cotação anterior.','🪙','dinheiro');s.version=9;}
 if(s.version===9){if(!s.governments||typeof s.governments!=='object'||Array.isArray(s.governments))reject();for(const g of Object.values(s.governments)){if(!g.justice||!g.civic||!g.civic.justice)reject();g.civic.justice={...Justice.defaults(),...g.civic.justice};Justice.initialize(g);}s.accountability=Justice.emptyPersonal();Government.syncJustice(s);s.version=10;}
 if(s.version===10){if(!s.governments||typeof s.governments!=='object'||Array.isArray(s.governments))reject();s.politicalWorld=Statecraft.createWorld(s.seed);s.timelines=Timelines.empty();s.workSchedule={days:5,hours:8};for(const g of Object.values(s.governments))Statecraft.initialize(g,s.year);s.version=11;}
 if(s.version===11){s.freedom=Freedom.empty();for(const k of Freedom.extraSkills)s.skills[k]=0;s.version=12;}
 if(!Freedom.valid(s))reject();
 if(!Timelines.valid(s,{D},validate)||!s.workSchedule||!num(s.workSchedule.days,0,7)||!Number.isInteger(s.workSchedule.days)||!num(s.workSchedule.hours,0,24))reject();
 if(!Justice.validPersonal(s,num,str)||Justice.restricted(s)&&s.politics&&(s.politics.office||s.politics.campaign))reject();
 if(!s.stats||!s.skills||Object.keys(D.stats).some(k=>!num(s.stats[k],0,100))||Object.keys(D.skills).some(k=>!num(s.skills[k],0,100)))reject();
 if(!M.valid(s.cash)||!M.valid(s.debt)||!num(s.hoursLeft,0,D.YEAR_HOURS)||!Number.isInteger(s.hoursLeft)||!num(s.reputation,0,100)||!num(s.fame,0,100)||!num(s.prison,0,150)||!num(s.record,0,1e8)||!num(s.jobLevel,1,1e5)||!num(s.performance,0,100)||!num(s.jobYears,0,1000)||!num(s.pension)||typeof s.retired!=='boolean')reject();
 if(!s.school||!['infancia','cursando','concluido','incompleto'].includes(s.school.status)||!num(s.school.grades,0,100)||!Array.isArray(s.degrees)||s.degrees.length>D.degrees.length||s.degrees.some(k=>!find(D.degrees,k))||new Set(s.degrees).size!==s.degrees.length)reject();
 if(s.college&&(!find(D.degrees,s.college.id)||!num(s.college.progress,0,6)||!Number.isInteger(s.college.progress)||typeof s.college.scholarship!=='boolean'))reject();
 if(s.job!==null&&!find(D.jobs,s.job))reject();if(!['leve','equilibrado','intenso'].includes(s.workload)||!find(D.lifestyles,s.lifestyle)||!['ele','ela','elu'].includes(s.pronoun))reject();
 const arr=(key,max)=>Array.isArray(s[key])&&s[key].length<=max;
 if(!arr('people',D.MAX_PEOPLE)||!arr('businesses',200)||!arr('assets',500)||!arr('history',350)||!arr('reports',8)||!arr('medals',150)||!arr('achievements',D.achievements.length)||!arr('eventMemory',20)||!arr('ancestors',30)||!num(s.generation,1,10000))reject();
 if(s.people.filter(p=>p&&p.kind==='friend').length>D.MAX_FRIENDS||s.people.some(p=>!p||!str(p.id,30)||!str(p.name,60)||!['parent','friend','partner','spouse','child','sibling','ex'].includes(p.kind)||!num(p.age,0,300)||!num(p.bond,0,100)||typeof p.alive!=='boolean'||!num(p.lastContactYear,0,s.year)||!Number.isInteger(p.lastContactYear)||!own(D.friendRoles,p.specialty)||!num(p.lastFavorYear,-1,s.year)||!Number.isInteger(p.lastFavorYear))||new Set(s.people.map(p=>p.id)).size!==s.people.length||s.people.filter(p=>p.alive&&['partner','spouse'].includes(p.kind)).length>1)reject();
 if(s.businesses.some(b=>!b||!str(b.id,30)||!find(D.businesses,b.type)||!num(b.level,1,100)||!Number.isInteger(b.level)||!['equilibrio','qualidade','escala'].includes(b.strategy)||!num(b.last,-1e12,1e12)))reject();
 if(s.assets.some(a=>!a||!str(a.id,30)||!find(D.assets,a.type)||!num(a.value)))reject();
 if(!s.investments||D.investments.some(i=>!M.valid(s.investments[i.id]))||!s.rankings||D.tournaments.some(t=>!num(s.rankings[t.id],0,1e8)))reject();
 if(!s.yearFlags||typeof s.yearFlags!=='object'||Array.isArray(s.yearFlags)||!s.tournamentYear||typeof s.tournamentYear!=='object'||Array.isArray(s.tournamentYear))reject();
 if(s.pending!==null&&!EVENTS.some(e=>e.id===s.pending))reject();if(s.eventMemory.some(k=>!EVENTS.some(e=>e.id===k))||s.achievements.some(k=>!find(D.achievements,k)))reject();
 if(s.history.some(h=>!h||!num(h.age,0,150)||!str(h.text)||!str(h.icon,20)||!str(h.category,30)))reject();
 if(s.reports.some(r=>!r||!num(r.age,0,150)||!num(r.year,0,10000)||!M.valid(r.income)||!M.valid(r.expenses)||!M.valid(r.balance,true)||(r.hoursUsed!==undefined&&(!num(r.hoursUsed,0,D.YEAR_HOURS)||!Number.isInteger(r.hoursUsed)))||!Array.isArray(r.lines)||r.lines.length>1600||r.lines.some(l=>!l||!str(l.label,150)||!M.valid(l.amount,true))))reject();
 if(s.medals.some(m=>!m||!str(m.id,30)||!find(D.tournaments,m.sport)||!num(m.tier,0,3)||!Number.isInteger(m.tier)||!num(m.age,0,150)||typeof m.champion!=='boolean'||!str(m.position,30)||!num(m.prize)||!num(m.points,0,1e8)))reject();
 if(s.ancestors.some(a=>!a||!str(a.name,60)||!num(a.age,0,150)||!M.valid(a.worth,true)))reject();
 if(s.tournament){const t=s.tournament;if(!find(D.tournaments,t.id)||!Number.isInteger(t.tier)||!D.tiers[t.tier]||!num(t.round,0,D.tiers[t.tier].rounds-1)||!Number.isInteger(t.round)||!num(t.stamina,0,100)||!num(t.prize)||!Array.isArray(t.opponents)||t.opponents.length!==D.tiers[t.tier].rounds||t.opponents.some(o=>!o||!str(o.name,60)||!num(o.power,0,100)||!['agressivo','tecnico','defensivo'].includes(o.style))||!Array.isArray(t.results)||t.results.length!==t.round)reject();if(t.results.some(r=>!r||!num(r.round,0,3)||!str(r.opponent,60)||typeof r.won!=='boolean'||!str(r.score,30)||!['agressivo','tecnico','defensivo'].includes(r.strategy)))reject();}
 if(!s.support||Object.keys(s.support).length!==Object.keys(D.supportTypes).length||Object.keys(D.supportTypes).some(k=>!num(s.support[k],0,D.MAX_PEOPLE)||!Number.isInteger(s.support[k]))||Object.values(s.support).reduce((a,b)=>a+b,0)>D.MAX_PEOPLE)reject();
 if(!arr('mastered',D.tournaments.length)||new Set(s.mastered).size!==s.mastered.length||s.mastered.some(k=>!find(D.tournaments,k)))reject();
 if(!['auto','none'].includes(s.transport)&&!s.assets.some(a=>a.id===s.transport&&own(D.vehicles,a.type)))reject();
 if(!arr('followups',32)||new Set(s.followups.map(q=>q.id)).size!==s.followups.length||s.followups.some(q=>!q||!Stories.followups.some(e=>e.id===q.id)||!num(q.sourceYear,0,s.year)||!Number.isInteger(q.sourceYear)||!num(q.dueYear,q.sourceYear,9999)||!Number.isInteger(q.dueYear)))reject();
 if(!arr('stories',60)||s.stories.some(q=>!q||!str(q.id,30)||!EVENTS.some(e=>e.id===q.event)||!num(q.year,0,s.year)||!num(q.age,0,150)||!str(q.title,150)||!str(q.icon,20)||!str(q.choice,200)||!str(q.narrative,1500)||typeof q.followup!=='boolean'||!Array.isArray(q.changes)||q.changes.length>120||q.changes.some(c=>!c||!str(c.label,150)||!(c.type==='money'?M.valid(c.delta,true):num(c.delta,-1e12,1e12))||!['money','hours','years','points','text'].includes(c.type)||![true,false,null].includes(c.good))))reject();
 if(!World.valid(s,num,str)||!Government.valid(s,num,str))reject();
 // Apenas campos conhecidos atravessam a fronteira do arquivo importado.
 const keys=Object.keys(create({seed:1}));const clean={};for(const k of keys)clean[k]=s[k];clean.build=D.VERSION;clean.lastResult=null;return clean;
}
const Engine={Freedom,Timelines,Statecraft,D,World,Government,EVENTS,create,act,validate,worth,salary,living,partner,children,rand,log,eventEligible,groupQuote,interaction,actionHours,tournamentDuration,Stories,timeQuote:Systems.timeQuote,chosenVehicle:Systems.chosenVehicle,favorQuote:Systems.favorQuote,favorList:Systems.favorList,allFavorsQuote:Systems.allFavorsQuote,sweepQuote:Systems.sweepQuote};
if(typeof module!=='undefined'&&module.exports)module.exports=Engine;else root.LifeEngine=Engine;
})(typeof globalThis!=='undefined'?globalThis:this);
